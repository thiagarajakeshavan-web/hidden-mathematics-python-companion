# அத்தியாய அட்டவணை [Chapter Index]

ஆசிரியர்: Keshavan Thiagaraja.

இது 26 அத்தியாயங்களை இணைக்கிறது: 25 முழுத் தொழில்நுட்ப அத்தியாயங்கள் [Full Technical Chapters], ஒரு முன்னோட்டம். 37 எடுத்துக்காட்டு அடையாளங்கள் [Case IDs] உள்ளன; சில ஒரே மூலநிரலில் [Source Code] இணைந்து இயங்குகின்றன. முதலில் [START_HERE_TA.md](START_HERE_TA.md) படியுங்கள். தலைப்புகள் வழிசெலுத்தல் உதவிகள் [Navigation Labels]; நூலின் அத்தியாயம்/எடுத்துக்காட்டு அடையாளங்களை [Case IDs] பொருத்திப் பாருங்கள்.

## தொகுதி 1

- [1. நேரியல் இயற்கணிதம் [Linear Algebra]](chapters/volume-01/chapter-01/README_TA.md) — V1C01-CASE01
- [2. நுண்கணிதம் [Calculus]](chapters/volume-01/chapter-02/README_TA.md) — V1C02-CASE01
- [3. நிகழ்தகவுக் கோட்பாடு [Probability Theory]](chapters/volume-01/chapter-03/README_TA.md) — V1C03-CASE01
- [4. விளக்க மற்றும் ஊகப் புள்ளியியல் [Descriptive and Inferential Statistics]](chapters/volume-01/chapter-04/README_TA.md) — V1C04-CASE01, V1C04-CASE02
- [5. உகப்பாக்கம் [Optimization]](chapters/volume-01/chapter-05/README_TA.md) — V1C05-CASE01, V1C05-CASE02, V1C05-CASE03, V1C05-CASE04
- [6. தகவல் கோட்பாடு [Information Theory]](chapters/volume-01/chapter-06/README_TA.md) — V1C06-CASE01
- [7. புள்ளியியல் அடித்தளங்கள் [Statistical Foundations]](chapters/volume-01/chapter-07/README_TA.md) — V1C07-CASE01, V1C07-CASE02
- [8. மாதிரி மதிப்பீடு [Model Evaluation]](chapters/volume-01/chapter-08/README_TA.md) — V1C08-CASE01
- [9. இயந்திரக் கற்றலின் வகைகள் [Types of Machine Learning]](chapters/volume-01/chapter-09/README_TA.md) — V1C09-CASE01
- [10. நேரியல் மற்றும் லாஜிஸ்டிக் பின்னடைவு [Linear and Logistic Regression]](chapters/volume-01/chapter-10/README_TA.md) — V1C10-CASE01, V1C10-CASE02, V1C10-CASE03
- [11. நைவ் பேய்ஸ் [Naive Bayes], அருகிலுள்ள k அண்டைப் புள்ளிகள் [kNN], ஆதரவு திசையன் இயந்திரம் [SVM]](chapters/volume-01/chapter-11/README_TA.md) — V1C11-CASE01
- [12. முடிவு மரங்கள் [Decision Trees], சீரற்ற காடுகள் [Random Forests], சரிவு ஊக்குவிப்பு [Gradient Boosting]](chapters/volume-01/chapter-12/README_TA.md) — V1C12-CASE01, V1C12-CASE02, V1C12-CASE03
- [13. குழுவாக்கம் [Clustering] மற்றும் பரிமாணக் குறைப்பு [Dimensionality Reduction]](chapters/volume-01/chapter-13/README_TA.md) — V1C13-CASE01, V1C13-CASE02
- [14. தொகுதி 2: ஒரு முன்னோட்டம்](chapters/volume-01/chapter-14/README_TA.md) — முன்னோட்டம்; நிரல் பயிற்சி [Code Lab] இல்லை

## தொகுதி 2

- [15. நரம்பியல் வலைப்பின்னல்கள் [Neural Networks] மற்றும் பின்பரவல் [Backpropagation]](chapters/volume-02/chapter-15/README_TA.md) — V2C15-CASE01, V2C15-CASE02
- [16. சுருள் செயல்பாடு [Convolution], மீள்சுழற்சி வலைப்பின்னல்கள் [Recurrent Networks], இயல்பாக்கம் [Normalization]](chapters/volume-02/chapter-16/README_TA.md) — V2C16-CASE01, V2C16-CASE02
- [17. கவனம் [Attention] மற்றும் இடநிலைத் தகவல் [Positional Information]](chapters/volume-02/chapter-17/README_TA.md) — V2C17-CASE01
- [18. சொற்கூறாக்கம் [Tokenization] மற்றும் மொழி மாதிரி நோக்கங்கள் [Language-model Objectives]](chapters/volume-02/chapter-18/README_TA.md) — V2C18-CASE01
- [19. நுண் பயிற்சி [Fine-tuning], விருப்ப உகப்பாக்கம் [Preference Optimization], குறைந்த தரவரிசைத் தழுவல் [LoRA]](chapters/volume-02/chapter-19/README_TA.md) — V2C19-CASE01
- [20. தகவல் மீட்பு [Retrieval], கோசைன் ஒற்றுமை [Cosine Similarity], தகுதிச் சோதனைகள் [Eligibility Gates]](chapters/volume-02/chapter-20/README_TA.md) — V2C20-CASE01
- [21. வரம்பிடப்பட்ட முகவர் பணிப்பாய்வுகள் [Bounded Agent Workflows]](chapters/volume-02/chapter-21/README_TA.md) — V2C21-CASE01
- [22. தரவின் புதுமை [Data Freshness] மற்றும் நிகழ்வு நேரச் சரித்தன்மை [Event-time Correctness]](chapters/volume-02/chapter-22/README_TA.md) — V2C22-CASE01
- [23. மதிப்பீடு [Evaluation], நிச்சயமின்மை [Uncertainty], நிகழ்தகவு ஒத்திசைவு [Calibration]](chapters/volume-02/chapter-23/README_TA.md) — V2C23-CASE01
- [24. சுருக்கம் [Compression] மற்றும் திறன்மிகு அனுமானம் [Efficient Inference]](chapters/volume-02/chapter-24/README_TA.md) — V2C24-CASE01
- [25. அதிகாரச் சோதனைகள் [Authority Checks], நியாயத்தன்மை [Fairness], தனியுரிமை [Privacy]](chapters/volume-02/chapter-25/README_TA.md) — V2C25-CASE01
- [26. கண்காணிப்பு [Monitoring], நம்பகத்தன்மை [Reliability], செயல்பாட்டுக் கணக்கீடு [Operational Arithmetic]](chapters/volume-02/chapter-26/README_TA.md) — V2C26-CASE01

## பழைய பாதைகளைக் [Paths] கண்டுபிடிப்பது

பழைய `V1Cxx` அடைவுகளும் [Folders], பகிரப்பட்ட காட்சிநிலை நிரல்களும் [Scenario Programs] `releases/volume-01-1.2.0/`-இல் உள்ளன. தொகுதி 2-இன் பழைய CASE01 பாதைகள் [Paths] `releases/volume-02-0.2.0/volume-02/edition-0.1.0/`-இல்; அத்தியாயங்கள் 15,16-இன் CASE02 பாதைகள் [Paths] `edition-0.2.0/`-இல். மூலநிரலுக்குள் [Source Code] பயன்படுத்தப்படும் பெயர்கள் மாற்றப்படவில்லை. [COMPANION_MAP.json](COMPANION_MAP.json) ஒவ்வொரு பாதையையும் [Path] துல்லியமாகப் பதிவு செய்கிறது.

