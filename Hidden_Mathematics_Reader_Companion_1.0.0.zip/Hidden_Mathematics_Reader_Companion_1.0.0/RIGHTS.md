# Authorship, access and dependency rights

Author: Keshavan Thiagaraja.

The author intends public access to the companion without purchase verification. Actual GitHub publication is pending. No new licence for the author's source, documentation or examples has been selected or granted by this combined reader package. Public readability is not automatically permission for every reuse or redistribution.

The two preserved releases contain their original provenance and dependency notices:

- [Volume 1 dependency notices](releases/volume-01-1.2.0/DEPENDENCIES.md)
- [Volume 1 original data provenance](releases/volume-01-1.2.0/DATA_PROVENANCE.md)
- [Volume 1 additions provenance](releases/volume-01-1.2.0/DATA_PROVENANCE_ADDITIONS.md)
- [Volume 2 rights and dependencies](releases/volume-02-0.2.0/RIGHTS_AND_DEPENDENCIES.md)

No dependency binaries, credentials, private source manuscripts, investor material or private user datasets are included. Fictional shopping and dietary examples are teaching data, not statements about the author or any real person's health. The original notices identify the limited publicly sourced nutrient reference data in the synthetic dinner example. No live retailer, courier or model-provider integration is implemented by this package.
