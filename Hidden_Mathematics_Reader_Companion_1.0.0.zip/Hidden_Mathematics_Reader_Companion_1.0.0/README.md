# The Hidden Mathematics: Python reader companion

**Author: Keshavan Thiagaraja**  
Reader-guide edition **1.0.0**, 6 October 2026. Separate English and Tamil reader guidance; one shared implementation.

Start with [English beginner guidance](START_HERE_EN.md) or [தமிழ் தொடக்க வழிகாட்டி](START_HERE_TA.md).

- [Chapter index in English](CHAPTER_INDEX_EN.md)
- [தமிழ் அத்தியாய அட்டவணை](CHAPTER_INDEX_TA.md)
- [Version matching](VERSION_MATCHING_EN.md) / [பதிப்புப் பொருத்தம்](VERSION_MATCHING_TA.md)
- [English worked examples](WORKED_EXAMPLES_EN.md) / [தமிழ் செய்முறை எடுத்துக்காட்டுகள்](WORKED_EXAMPLES_TA.md)
- [Verification record](VERIFICATION_EN.md) / [சரிபார்ப்புப் பதிவு](VERIFICATION_TA.md)

The two books contain the mathematics, interpretation and enterprise discussion. This companion contains the executable setup/run instructions and Python source. Volume 1 has full Chapters 1–13 and a brief Chapter 14 preview with no required lab. Volume 2 has full Chapters 15–26.

## What is preserved

The two source releases remain intact under `releases/volume-01-1.2.0/` and `releases/volume-02-0.2.0/`. New chapter-by-chapter entry pages live under `chapters/`. They link to the existing tested implementations rather than copying or renaming algorithms. [COMPANION_MAP.json](COMPANION_MAP.json) is the exact chapter, case, source and result map. `run_chapter.py` is a small additive launcher, not a new algorithm.

## Access and scope

Public GitHub access is intended for everyone, without a book-purchase gate. Publication is still pending; this package has no verified repository URL or published release tag. The GitHub instructions describe what to do once the author supplies a verified link. The supplied ZIP can be used locally now.

These are offline, synthetic teaching examples, not production ShopSmart AI services, live retail offers, trained commercial LLMs, allergy guarantees or investment claims. No login, API key, paid API, GPU or model download is needed to run the supplied labs after installing their dependencies. No new licence is granted for the author's work; see [RIGHTS.md](RIGHTS.md).
