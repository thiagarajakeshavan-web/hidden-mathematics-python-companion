#!/usr/bin/env python3
"""Run preserved chapter entry points locally; never download, install or publish."""
from pathlib import Path
import argparse
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def load_map():
    return json.loads((ROOT / 'COMPANION_MAP.json').read_text(encoding='utf-8'))


def select_cases(volume, chapter, case=None):
    if chapter == 14:
        raise ValueError('Chapter 14 is the Volume 1 preview. It has no required Python lab. Choose 1–13 or 15–26.')
    entry = next((c for c in load_map()['chapters'] if c['volume'] == volume and c['chapter'] == chapter), None)
    if entry is None:
        raise ValueError('Volume 1 contains Chapters 1–13 and preview 14; Volume 2 contains Chapters 15–26. Check both numbers.')
    cases = entry['cases']
    if case is not None:
        expected = f'V{volume}C{chapter:02d}-CASE{case:02d}'
        cases = [c for c in cases if c['case_id'] == expected]
        if not cases:
            available = ', '.join(c['case_id'] for c in entry['cases'])
            raise ValueError(f'No CASE{case:02d} in this chapter. Available: {available}')
    return cases


def execution_plan(cases):
    plan = []
    seen = set()
    for case in cases:
        relative = Path(case['entrypoint'])
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Invalid local entry point in companion map.')
        source = (ROOT / relative).resolve()
        if not source.is_relative_to(ROOT) or not source.is_file():
            raise ValueError(f'Missing local source file: {relative}. Extract the complete companion ZIP.')
        if source not in seen:
            plan.append((source, case))
            seen.add(source)
    return plan


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--volume', type=int, required=True, choices=(1, 2))
    parser.add_argument('--chapter', type=int, required=True)
    parser.add_argument('--case', type=int, help='Optional case number, for example 2 for CASE02.')
    parser.add_argument('--list', action='store_true', help='Show source/result paths without running code.')
    args = parser.parse_args(argv)
    try:
        cases = select_cases(args.volume, args.chapter, args.case)
        plan = execution_plan(cases)
    except ValueError as error:
        parser.error(str(error))
    if args.list:
        print(json.dumps(cases, ensure_ascii=False, indent=2))
        return 0
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    for source, case in plan:
        print(f"Running {case['case_id']}: {case['entrypoint']}", flush=True)
        if case['bundled_entrypoint']:
            print('This preserved lab runs the chapter’s bundled cases together; inspect the named result section.', flush=True)
        result = subprocess.run([sys.executable, str(source)], env=env, check=False)
        if result.returncode:
            print(f"Stopped: {case['case_id']} returned status {result.returncode}. Read the error above; do not change saved expected results to hide it.", file=sys.stderr)
            return result.returncode
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
