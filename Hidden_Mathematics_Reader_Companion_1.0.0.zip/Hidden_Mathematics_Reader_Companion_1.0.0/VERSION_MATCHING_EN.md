# Match the book, guide and source release

Author: Keshavan Thiagaraja. Reader-guide edition 1.0.0, dated 6 October 2026.

There are three different labels:

1. **Book edition/version:** the identifier on the particular English or Tamil manuscript you are reading. Do not assume a book's version number equals a software version.
2. **Reader-guide edition 1.0.0:** the new combined navigation pages, this guide, the map and the launcher.
3. **Preserved source releases:** Volume 1 `1.2.0-author-review` and Volume 2 `0.2.0-author-review`.

The matching English and Tamil books use the same chapter/case IDs and the same Python source. Their prose is separate; code is not translated.

## Exact locations

| Material | Combined-package location |
|---|---|
| All Volume 1 source | `releases/volume-01-1.2.0/` |
| All Volume 2 source | `releases/volume-02-0.2.0/` |
| Volume 1 chapter navigation | `chapters/volume-01/chapter-01/` through `chapter-14/` |
| Volume 2 chapter navigation | `chapters/volume-02/chapter-15/` through `chapter-26/` |
| Exact IDs, sources, inputs and outputs | `COMPANION_MAP.json` |

The Volume 1 source folder `V1C02` still means Chapter 2. Source release 1.2.0 adds new cases without changing earlier chapter implementations. Consequently an original README may retain a 1.0.0 or 1.1.0 content label, and an older helper may retain a historical constant. The current package identity comes from the root mapping and the release's `MANIFEST.json`, not one historical line in a copied file.

The Volume 2 0.2.0 source release contains the twelve original CASE01 laboratories in `volume-02/edition-0.1.0/`. The two CASE02 additions, Chapter 15 optimizers and Chapter 16 normalization, are in `volume-02/edition-0.2.0/`. These paths are intentional and preserved. Do not rename them to make their numbers identical: the registry depends on them.

The new `chapters/` pages provide one beginner entry point per chapter. They do not duplicate the source. Some cases live in shared scenario folders; the map links to their existing authoritative implementation. V1C12-CASE02/03 are sections of `V1C12/lab.py`; V1C13-CASE02 is a section of `V1C13/lab.py`. Their result sections are recorded explicitly.

## Numbering and historical reconciliation

The current structure is full Chapters 1–13 in Volume 1, brief preview Chapter 14, then full Chapters 15–26 in Volume 2. If an older outline labels the deep-learning sequence 14–25, add one to those old technical chapter numbers to obtain the current 15–26 sequence. Do not apply this translation to an already-current case ID. The present code already uses the current sequence. Chapter 14 has no required code package.

## A future GitHub release

There is no verified public repository URL, release tag or public commit in this package. Once publication is complete, the author should provide the precise companion release/tag and commit corresponding to each book edition. Match those recorded identifiers before downloading or cloning. GitHub's default branch can change. Tags can also move; a recorded commit gives a more precise content reference. See [GitHub releases and tags](https://docs.github.com/en/repositories/releasing-projects-on-github/viewing-your-repositorys-releases-and-tags) and [archive stability](https://docs.github.com/en/repositories/working-with-files/using-files/downloading-source-code-archives).

## Current checks, not old counts

Use 178 tests for Volume 1, 287 for Volume 2 and 18 for the new navigation layer. Earlier counts in preserved logs are historical. Retaining their exact bytes preserves the original release evidence; it does not make those old counts current. The current combined verification record is [VERIFICATION_EN.md](VERIFICATION_EN.md).
