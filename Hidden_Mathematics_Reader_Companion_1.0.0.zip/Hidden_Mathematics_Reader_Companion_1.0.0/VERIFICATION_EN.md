# Verification record: reader-guide edition 1.0.0

Author: Keshavan Thiagaraja. Checks executed on 6 October 2026.

## Environment actually used

- CPython 3.12.14, Linux x86_64
- NumPy 2.3.5; SciPy 1.17.0; scikit-learn 1.8.0; joblib 1.5.3; threadpoolctl 3.6.0
- Already-installed pinned dependencies, matching the preserved releases
- CPU execution; no model download, paid API, service account or credentials

A fresh project-local virtual environment was created successfully and its Python/pip were checked. Dependencies were not installed into that empty environment. Numerical runs used the already-installed pinned environment. Windows, macOS, a fresh internet dependency install and public GitHub download/clone access were not tested.

## Tests and runs completed

| Check | Observed result |
|---|---|
| Volume 1 full unittest suite, warnings as errors | 178 passed |
| Volume 2 full unittest suite, warnings as errors | 287 passed |
| Additive reader-navigation unittest suite, warnings as errors | 18 passed |
| Total test methods across the three suites | 483 passed |
| Volume 1 original all-lab runner | Passed; 13 chapter labs and two earlier ShopSmart additions |
| Volume 1 additional-case runner | Passed; five later additions |
| Volume 2 full runner with recorded-result verification | 14 cases passed |
| New launcher across all full technical chapters | All 25 chapter launches passed |
| New launcher from an unrelated current working folder | V1C02 and V2C15 CASE01 passed |
| Preview 14, unavailable case, wrong volume, unsafe/missing path errors | Checked in the navigation suite |

The exact source/result map has 26 chapter entries, 37 case identifiers and 34 unique original entry points. Chapter 14 is a preview. Several cases share one source entry point; therefore the case count, entry-point count and test count are different quantities.

The complete numerical smoke run used a fresh filesystem copy, so it did not alter the packaged release outputs. [validation.json](reports/validation.json) records commands, exit statuses and scope. The final input-path lists were deduplicated without modifying any algorithm or launcher; the 18 navigation tests passed again afterward.

## Original source preservation

Every original archive file was compared byte-for-byte: **120 Volume 1 files** and **113 Volume 2 files**, with no differences and no added files inside those release trees. Interpreter cache files are excluded from the distributed archive.

The original integrity programs also passed: **119 inventoried Volume 1 files**, **112 inventoried Volume 2 files**. Those inventories omit their own manifest file, explaining the one-file difference from the archive counts. Volume 1's separate baseline checker confirmed **85 earlier files** unchanged. New navigation, bilingual guidance, launcher and reports live outside the preserved release folders.

The original archive contents and the new source-preservation check establish continuity. An integrity hash does not authenticate the publisher, prove every mathematical assertion or replace reviewing source and assumptions.

## Evidence files

- [Volume 1 tests](reports/v1_tests.log)
- [Volume 2 tests](reports/v2_tests.log)
- [Final navigation tests](reports/reader_tests_final.log)
- [Volume 1 integrity](reports/v1_integrity.log), [Volume 2 integrity](reports/v2_integrity.log), [baseline preservation](reports/v1_preservation.log)
- [Volume 1 all-lab run](reports/v1_all.log), [additions run](reports/v1_additions.log)
- Fresh worked outputs: [V1C02-CASE01](reports/examples/V1C02-CASE01.json), [V2C15-CASE01](reports/examples/V2C15-CASE01.json), [V2C17-CASE01](reports/examples/V2C17-CASE01.json)

The new chapter pages and indices were checked against real local files. Link existence is not a claim that a future GitHub URL is live. [START_HERE_EN.md](START_HERE_EN.md) cites official GitHub/Python documentation for general interface and setup instructions. Those instructions were checked as documentation; this project's public GitHub flow remains unverified because publication is pending.

## Limits that remain

These tests validate the stated synthetic arithmetic, interfaces, tolerances and failure cases. They are not a proof of universal correctness, production readiness, generalization, privacy compliance, safety, real retailer support or real-world savings. No new reuse licence, public repository URL or publication claim is introduced. Old logs inside the preserved releases remain historical; use this report for the current combined guide.
