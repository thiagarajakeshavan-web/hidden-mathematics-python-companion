# Chapter-to-code index

Author: Keshavan Thiagaraja.

This maps all 26 chapters: 25 full technical chapters and one preview. There are 37 case identifiers; some share a source entry point. Start with [START_HERE_EN.md](START_HERE_EN.md). Topic labels are navigation aids; match the book’s chapter and exact case IDs.

## Volume 1

- [1. Linear Algebra](chapters/volume-01/chapter-01/README_EN.md) — V1C01-CASE01
- [2. Calculus](chapters/volume-01/chapter-02/README_EN.md) — V1C02-CASE01
- [3. Probability Theory](chapters/volume-01/chapter-03/README_EN.md) — V1C03-CASE01
- [4. Descriptive and Inferential Statistics](chapters/volume-01/chapter-04/README_EN.md) — V1C04-CASE01, V1C04-CASE02
- [5. Optimization](chapters/volume-01/chapter-05/README_EN.md) — V1C05-CASE01, V1C05-CASE02, V1C05-CASE03, V1C05-CASE04
- [6. Information Theory](chapters/volume-01/chapter-06/README_EN.md) — V1C06-CASE01
- [7. Statistical Foundations](chapters/volume-01/chapter-07/README_EN.md) — V1C07-CASE01, V1C07-CASE02
- [8. Model Evaluation](chapters/volume-01/chapter-08/README_EN.md) — V1C08-CASE01
- [9. Types of Machine Learning](chapters/volume-01/chapter-09/README_EN.md) — V1C09-CASE01
- [10. Linear and Logistic Regression](chapters/volume-01/chapter-10/README_EN.md) — V1C10-CASE01, V1C10-CASE02, V1C10-CASE03
- [11. Naive Bayes, kNN and SVM](chapters/volume-01/chapter-11/README_EN.md) — V1C11-CASE01
- [12. Decision Trees, Random Forests and Gradient Boosting](chapters/volume-01/chapter-12/README_EN.md) — V1C12-CASE01, V1C12-CASE02, V1C12-CASE03
- [13. Clustering and Dimensionality Reduction](chapters/volume-01/chapter-13/README_EN.md) — V1C13-CASE01, V1C13-CASE02
- [14. Looking Ahead to Volume 2](chapters/volume-01/chapter-14/README_EN.md) — Preview; no required lab

## Volume 2

- [15. Neural networks and backpropagation](chapters/volume-02/chapter-15/README_EN.md) — V2C15-CASE01, V2C15-CASE02
- [16. Convolution, recurrent networks and normalization](chapters/volume-02/chapter-16/README_EN.md) — V2C16-CASE01, V2C16-CASE02
- [17. Attention and positional information](chapters/volume-02/chapter-17/README_EN.md) — V2C17-CASE01
- [18. Tokenization and language-model objectives](chapters/volume-02/chapter-18/README_EN.md) — V2C18-CASE01
- [19. Fine-tuning, preference optimization and LoRA](chapters/volume-02/chapter-19/README_EN.md) — V2C19-CASE01
- [20. Retrieval, cosine similarity and eligibility gates](chapters/volume-02/chapter-20/README_EN.md) — V2C20-CASE01
- [21. Bounded agent workflows](chapters/volume-02/chapter-21/README_EN.md) — V2C21-CASE01
- [22. Data freshness and event-time correctness](chapters/volume-02/chapter-22/README_EN.md) — V2C22-CASE01
- [23. Evaluation, uncertainty and calibration](chapters/volume-02/chapter-23/README_EN.md) — V2C23-CASE01
- [24. Compression and efficient inference](chapters/volume-02/chapter-24/README_EN.md) — V2C24-CASE01
- [25. Authority, fairness and privacy checks](chapters/volume-02/chapter-25/README_EN.md) — V2C25-CASE01
- [26. Monitoring, reliability and operational arithmetic](chapters/volume-02/chapter-26/README_EN.md) — V2C26-CASE01

## Find an existing source path

Existing `V1Cxx` folders and shared scenario programs remain under `releases/volume-01-1.2.0/`. Original Volume 2 CASE01 paths remain under `releases/volume-02-0.2.0/volume-02/edition-0.1.0/`; the Chapter 15/16 CASE02 additions remain under `edition-0.2.0/`. No implementation identifiers were renamed. [COMPANION_MAP.json](COMPANION_MAP.json) records every exact path.

