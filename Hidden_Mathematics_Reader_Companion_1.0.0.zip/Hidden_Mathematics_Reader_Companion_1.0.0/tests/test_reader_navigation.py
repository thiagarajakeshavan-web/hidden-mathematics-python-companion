"""Independent checks for additive reader navigation; original suites stay separate."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('reader_runner', ROOT/'run_chapter.py')
runner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)

class ReaderNavigationTests(unittest.TestCase):
    def test_approved_chapter_numbering(self):
        m=runner.load_map()
        self.assertEqual([c['chapter'] for c in m['chapters']],list(range(1,27)))
        self.assertEqual([c['chapter'] for c in m['chapters'] if c['cases']],list(range(1,14))+list(range(15,27)))
    def test_unique_case_identifiers(self):
        ids=[c['case_id'] for ch in runner.load_map()['chapters'] for c in ch['cases']]
        self.assertEqual(len(ids),37)
        self.assertEqual(len(ids),len(set(ids)))
    def test_all_sources_and_results_exist(self):
        for ch in runner.load_map()['chapters']:
            for c in ch['cases']:
                for field in ['source','entrypoint','guide_en','result']:
                    self.assertTrue((ROOT/c[field]).is_file(),c[field])
                for path in c['inputs']:
                    self.assertTrue((ROOT/path).is_file(),path)
    def test_result_subsections_exist(self):
        for ch in runner.load_map()['chapters']:
            for c in ch['cases']:
                data=json.loads((ROOT/c['result']).read_text())
                if c['result_key']:
                    self.assertEqual(data[c['result_key']]['case_id'],c['case_id'])
    def test_v1_case_counts(self):
        self.assertEqual(len(runner.select_cases(1,5)),4)
        self.assertEqual(len(runner.select_cases(1,10)),3)
        self.assertEqual(len(runner.select_cases(1,12)),3)
        self.assertEqual(len(runner.select_cases(1,13)),2)
    def test_v2_new_cases(self):
        for ch in [15,16]:
            self.assertEqual(len(runner.select_cases(2,ch)),2)
            self.assertIn('edition-0.2.0',runner.select_cases(2,ch,2)[0]['entrypoint'])
            self.assertIn('edition-0.1.0',runner.select_cases(2,ch,1)[0]['entrypoint'])
    def test_exact_case_selection(self):
        self.assertEqual(runner.select_cases(1,5,3)[0]['case_id'],'V1C05-CASE03')
    def test_bundled_entrypoint_deduplicated(self):
        self.assertEqual(len(runner.execution_plan(runner.select_cases(1,12))),1)
        self.assertEqual(len(runner.execution_plan(runner.select_cases(1,13))),1)
    def test_preview_has_clear_error(self):
        with self.assertRaisesRegex(ValueError,'preview'):
            runner.select_cases(1,14)
    def test_wrong_volume_has_clear_error(self):
        with self.assertRaisesRegex(ValueError,'Volume 1'):
            runner.select_cases(2,2)
    def test_missing_case_has_clear_error(self):
        with self.assertRaisesRegex(ValueError,'Available:'):
            runner.select_cases(1,2,8)
    def test_missing_source_has_clear_error(self):
        with self.assertRaisesRegex(ValueError,'Missing local source'):
            runner.execution_plan([{'entrypoint':'missing.py'}])
    def test_parent_traversal_rejected(self):
        with self.assertRaisesRegex(ValueError,'Invalid local'):
            runner.execution_plan([{'entrypoint':'../missing.py'}])
    def test_absolute_source_rejected(self):
        with self.assertRaisesRegex(ValueError,'Invalid local'):
            runner.execution_plan([{'entrypoint':'/tmp/missing.py'}])
    def test_cli_list_from_unrelated_folder(self):
        with tempfile.TemporaryDirectory() as folder:
            result=subprocess.run([sys.executable,str(ROOT/'run_chapter.py'),'--volume','2','--chapter','15','--case','1','--list'],cwd=folder,capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(json.loads(result.stdout)[0]['case_id'],'V2C15-CASE01')
    def test_cli_preview_nonzero(self):
        result=subprocess.run([sys.executable,str(ROOT/'run_chapter.py'),'--volume','1','--chapter','14'],capture_output=True,text=True)
        self.assertEqual(result.returncode,2)
        self.assertIn('preview',result.stderr)
    def test_cli_invalid_case_nonzero(self):
        result=subprocess.run([sys.executable,str(ROOT/'run_chapter.py'),'--volume','2','--chapter','17','--case','2'],capture_output=True,text=True)
        self.assertEqual(result.returncode,2)
        self.assertIn('Available',result.stderr)
    def test_no_published_url_claim(self):
        self.assertIsNone(runner.load_map()['publication_url'])

if __name__=='__main__': unittest.main()
