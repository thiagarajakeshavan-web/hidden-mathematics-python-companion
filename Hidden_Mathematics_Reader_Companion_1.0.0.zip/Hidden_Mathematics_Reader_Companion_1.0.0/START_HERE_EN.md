# Start here: from a book chapter to a working Python example

Author: Keshavan Thiagaraja. Reader-guide edition 1.0.0. This is the executable companion guide, separate from the books.

## 1. What you need, and what you are looking at

A book chapter teaches the problem and mathematics. A **repository** is a collection of files. A **folder** groups related files. A **source file** ending in `.py` contains Python instructions. A **terminal** is the window where you enter commands. A **result file** ending in `.json` stores labelled values. A **test** checks a specified property, such as whether an analytical derivative agrees with a numerical approximation.

You need a computer with a trusted Python 3.12 installation, an ordinary text editor, a writable folder and the complete companion. No previous Git knowledge is required. You do not need to buy a cloud service or install a deep-learning framework for these labs. Installing dependencies may require internet; the actual supplied cases run offline.

Opening a `.py` file on GitHub only displays it. It does not run the experiment. Likewise, opening a saved `results.json` shows a previous run, not a new computation. To produce a new result, download the whole package and run the relevant command locally.

## 2. Start from the correct release

For this reader-guide edition, Volume 1 uses source release **1.2.0-author-review**; Volume 2 uses source release **0.2.0-author-review**. These are code-release identifiers, not interchangeable book-edition numbers. Check the book's companion note against [VERSION_MATCHING_EN.md](VERSION_MATCHING_EN.md).

Public repository publication is pending. Do not guess a GitHub address. Use the supplied archive now, or the author's verified public link once one is supplied. The following GitHub navigation describes the future published copy; it does not claim that copy has been uploaded or tested publicly.

## 3. Find a chapter in GitHub's browser view

Once the verified repository is available:

1. Open its main page. Read `README.md`, then `START_HERE_EN.md`.
2. Check the release/tag named in the book or release note. A moving default branch may contain later edits.
3. Open `CHAPTER_INDEX_EN.md`. Choose the volume, chapter and exact case identifier printed in the book.
4. Follow the chapter link. For Chapter 2 this opens `chapters/volume-01/chapter-02/README_EN.md`.
5. Follow that page's source link to `releases/volume-01-1.2.0/V1C02/lab.py`. The same page links to inputs, saved results and the original guide.
6. Read the case assumptions before interpreting a number. Navigate back through the file path or browser Back button when needed.

A Chapter 15 page has both CASE01 and CASE02. Choose the identifier the book discusses. Their shared chapter number does not make them the same experiment. GitHub code navigation is described in [GitHub's official guide](https://docs.github.com/en/repositories/working-with-files/using-files/navigating-code-on-github).

## 4. Download ZIP or clone?

**Download is the beginner route.** A ZIP is a snapshot; it needs no Git commands. Once the repository exists, use **Code → Download ZIP** for the selected view, or **Releases → the matching release → Assets** for its archive. Prefer the explicitly named companion asset when supplied and read its release note. Extract the entire archive. Do not download only a `lab.py` or `run.py`: it may need shared helpers and fixtures. [Official ZIP instructions](https://docs.github.com/en/repositories/working-with-files/using-files/downloading-source-code-archives).

**Clone is optional.** If Git is already installed and you want history, open **Code**, select **HTTPS**, and copy the verified URL. In a terminal, type `git clone`, a space, and that copied URL. This creates a local repository. Select the documented release/tag before running; do not blindly pull new changes into your only working experiment. No usable clone command is printed here because the project URL is not verified. [Official cloning instructions](https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository).

Keep an untouched archive as a reference and extract a separate working copy. Never put passwords, tokens or private datasets in a repository or a support screenshot. Public availability does not automatically grant a reuse licence.

## 5. Find the root folder and open a terminal

After extraction, open the folder containing **this file**, `README.md`, `COMPANION_MAP.json`, `run_chapter.py`, `chapters/` and `releases/`. This is the **combined companion root**. A ZIP extractor may add one outer folder; open it until these files are visible. Commands below assume this root is your current folder unless stated otherwise.

Open a terminal and use `cd` followed by the actual extracted folder path. Put a path containing spaces in quotes. On Windows use PowerShell. On Linux, macOS or Windows WSL Ubuntu use its terminal. WSL uses the Linux commands, not the PowerShell paths. On a trusted existing editor with an integrated terminal, open the companion folder and use that terminal. An editor is optional.

Copy only the command text. Do not type a displayed `$` or `PS>` prompt. If you see Python's `>>>` prompt, leave the interactive interpreter with `exit()` first. Commands that begin with `python` belong in the terminal, not in a Python source file or JSON file.

## 6. Set up Python and the dependencies

The verified runtime is **CPython 3.12.14 on Linux x86_64**. Exact package versions are pinned in each release. This is not a claim that these are the newest packages. Other Python versions and operating systems are unverified for this package. If Python is absent, use the [official Python download site](https://www.python.org/downloads/) or your platform's trusted package route. Verify the installed version before continuing.

A project-local virtual environment keeps these packages separate from other projects. The commands use its interpreter directly, so activation and PowerShell execution-policy changes are unnecessary. Python documents this in its [virtual-environment guide](https://docs.python.org/3.12/library/venv.html).

### Windows PowerShell

Run from the combined companion root:

```powershell
py -3.12 --version
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r releases/volume-01-1.2.0/requirements.txt
.\.venv\Scripts\python.exe run_chapter.py --volume 1 --chapter 2
```

For Volume 2 only, replace the install command with:

```powershell
.\.venv\Scripts\python.exe -m pip install -r releases/volume-02-0.2.0/requirements.lock
.\.venv\Scripts\python.exe run_chapter.py --volume 2 --chapter 15 --case 1
```

### Linux, macOS or WSL Ubuntu

```sh
python3.12 --version
python3.12 -m venv .venv
.venv/bin/python -m pip install -r releases/volume-01-1.2.0/requirements.txt
.venv/bin/python run_chapter.py --volume 1 --chapter 2
```

For Volume 2 only:

```sh
.venv/bin/python -m pip install -r releases/volume-02-0.2.0/requirements.lock
.venv/bin/python run_chapter.py --volume 2 --chapter 15 --case 1
```

The Volume 1 pins include NumPy 2.3.5, which is the only third-party dependency of Volume 2; installing the Volume 1 requirements therefore covers both supplied source releases. Dependency installation uses your configured package index and may need internet. The download includes no dependency binaries. Do not use administrator privileges, `sudo pip`, unsolicited installers or system-security changes to work around a setup error.

The numerical commands and tests were executed using the already-installed pinned packages. A fresh internet dependency installation and Windows/macOS execution were **not** performed. A clean archive-extraction test is different from a fresh package-installation test; see [verification scope](VERIFICATION_EN.md).

## 7. A single command pattern for any chapter

In the commands below, `python` means your selected environment's interpreter: `.venv/bin/python` on Linux/macOS/WSL, or `.\.venv\Scripts\python.exe` on Windows. Substitute it consistently. Do not mix interpreters for installation and execution.

```sh
python run_chapter.py --volume 1 --chapter 2
python run_chapter.py --volume 2 --chapter 15 --case 1
python run_chapter.py --volume 2 --chapter 15 --case 2
python run_chapter.py --volume 1 --chapter 5 --list
```

Without `--case`, the launcher runs every distinct entry point mapped to that chapter. `--list` only displays paths. Volume 1 Chapter 12's three cases share one original lab; Chapter 13's two cases do too. Selecting one of those case numbers still runs that preserved bundled lab. The chapter page tells you which JSON section belongs to the case.

Chapter 14 intentionally returns a clear preview message rather than running a lab. Wrong volume/chapter combinations or unavailable case numbers return an error. The launcher uses paths relative to its own location: from another working folder, pass the full path to `run_chapter.py`.

## 8. Recognize a successful run

The launcher announces the case, then the preserved program prints its result. Volume 1 programs write the corresponding result file inside their release folder. Some print a short summary, so open the linked result file for all fields. Volume 2's case entry points compute results, compare them to `expected.json`, then print JSON; they do not overwrite the expected file.

For V1C02-CASE01, the scalar `analytic_derivative` is **−4.0** and `central_difference` is approximately **−4.000000000004**. The initial network loss is **0.5**; the simultaneous rate-0.01 update gives **0.293378**. V2C15-CASE01 starts at loss **0.73394696731759** and reaches **0.6789767190265269** after its specified single step. Use [the worked examples](WORKED_EXAMPLES_EN.md) to connect every number to the mathematics.

Small last-digit differences can come from floating-point arithmetic. Tests use tolerances; do not compare screenshots character-for-character. An unchanged saved result alone is not proof that you ran anything successfully. Read any error and the program's exit status.

## 9. Run the independent checks and all supplied labs

From the combined root, after choosing the right interpreter:

```sh
python releases/volume-01-1.2.0/verify_manifest.py
python releases/volume-02-0.2.0/verify_manifest.py
python -W error -m unittest discover -s releases/volume-01-1.2.0/tests -v
python -W error -m unittest discover -s releases/volume-02-0.2.0/tests -v
python -W error -m unittest discover -s tests -v
```

The current counts are **178 Volume 1 tests**, **287 Volume 2 tests**, and **18 new reader-navigation tests**, each ending in `OK`. Older copied guidance mentioning 55, 120 or 226 tests describes earlier release stages. Use these current counts and the verification report for this combined edition.

To run everything, including the five Volume 1 additions:

```sh
python releases/volume-01-1.2.0/run_all.py
python releases/volume-01-1.2.0/run_additions.py
python releases/volume-02-0.2.0/run_cases.py --verify
```

The original V1 `run_all.py` alone does not run all 1.2.0 additions. It regenerates chapter result files and three SVG charts; `run_additions.py` covers the five later cases. V2 runs 14 labs. Check file integrity before experimenting: intentional edits or regenerated output differences can invalidate stored checksums. A checksum check detects changed files, not trusted authorship or mathematical correctness.

## 10. Learn by changing one thing

1. Read the chapter's business question and write down the relevant equation.
2. Read the case's synthetic inputs, units and assumptions.
3. Calculate one small intermediate quantity by hand.
4. Run the unchanged case. Find that quantity in the result.
5. Explain why it agrees, or identify exactly where it differs.
6. Copy the whole release into a separate experiment folder. Change one documented input or parameter, then predict what will happen before running again.
7. Record the original value, new value, prediction, measured result and explanation. Keep the untouched reference.

Some Volume 1 CSVs mirror constants in `lab.py`; editing a mirror alone does not change the program. Follow the case guide and actual input-loading code. For modified Volume 2 fixtures, use its `run_cases.py` without `--verify` inside the experiment copy to inspect new output. The normal checked entry points should reject results that no longer match the untouched reference. Never edit `expected.json` merely to silence a failure.

A toy loss decrease is evidence about that numerical example. It is not proof that a production system improved. Protect held-out data; do not use final-test scores to choose parameters. Synthetic dietary gates are not a real allergy-safety assessment.

## 11. Troubleshooting

- **Python or `py -3.12` is not found:** check the official installation and version. An editor extension is not necessarily a Python interpreter.
- **`No module named numpy`, `scipy` or `sklearn`:** run the requirements installation with the same environment's interpreter used for the lab. `sklearn` is imported from the package named `scikit-learn`.
- **Cannot open `run_chapter.py`:** your terminal is in the wrong folder, or the ZIP is not fully extracted. Locate the root files listed above.
- **Permission denied when saving results:** use a writable extracted working copy, not the compressed ZIP view or a protected program folder.
- **PowerShell blocks activation:** these instructions do not need activation. Invoke `.\.venv\Scripts\python.exe` directly; do not weaken execution policy.
- **Missing source/fixture:** extract the complete archive again into a new folder; single-file downloads are insufficient.
- **A test fails or V2 reports a mismatch:** keep the error, command, case ID, Python version and dependency versions; compare an untouched copy before investigating your edits. Do not patch an expected value to force success.
- **A Chapter 14 lab is missing:** that is intentional; continue the preview in the book and begin the next full lab at Chapter 15.
- **GitHub asks for purchase verification or the link is unavailable:** no purchase gate is intended. Verify the author's link; a prepared archive is not proof of public publication.

When asking for help, include the chapter/case ID, release identifiers, operating system, exact command and full error. Remove usernames, local private paths and any confidential information from shared screenshots.
