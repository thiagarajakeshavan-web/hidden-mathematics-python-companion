# Read the mathematics in the output

Author: Keshavan Thiagaraja. All examples below are synthetic and were executed again for reader-guide edition 1.0.0. Commands use `python` as shorthand for the environment interpreter specified in [START_HERE_EN.md](START_HERE_EN.md). Run them from the combined companion root.

## Example 1: a derivative you can check by hand

**Volume 1, Chapter 2, V1C02-CASE01.** Open [the chapter page](chapters/volume-01/chapter-02/README_EN.md), [source](releases/volume-01-1.2.0/V1C02/lab.py) and [recorded rerun](reports/examples/V1C02-CASE01.json).

```sh
python run_chapter.py --volume 1 --chapter 2
```

### Predict first

The function is f(w) = (2w − 3)², evaluated at w = 1. The inner expression is 2(1) − 3 = −1, so f(1) = 1.

Use the chain rule: the outer square contributes 2(2w − 3); the inner linear function contributes 2. Thus f′(w) = 4(2w − 3), giving f′(1) = −4. This is the local slope. For a sufficiently small positive change in w, the function initially decreases.

The central-difference approximation uses h = 0.00001:

[f(1 + h) − f(1 − h)] / (2h).

The executed values are approximately 0.9999600004 and 1.0000400004. Their difference is about −0.00008; dividing by 0.00002 gives about −4. The JSON contains:

- `scalar.w`: 1.0
- `scalar.f_w`: 1.0
- `scalar.analytic_derivative`: −4.0
- `scalar.central_difference`: −4.000000000004

That tiny difference is ordinary numerical rounding. A numerical check supports this calculation; it is not a proof that every implementation or every point is differentiable.

### Follow the same idea through a small network

The source uses parameter order w, b, v, c = 0.5, 0.5, 2, 0; input x = 2; target = 4.

1. z = wx + b = 0.5×2 + 0.5 = 1.5.
2. h = max(z, 0) = 1.5. Here ReLU is on its positive, differentiable branch.
3. Prediction = vh + c = 2×1.5 + 0 = 3.
4. Error = prediction − target = −1.
5. Loss = error²/2 = 0.5.

Using the chain rule at the original parameters gives gradients in the same order: **[−4, −2, −1.5, −1]**. For example, the w gradient is error × v × 1 × x = −1×2×1×2 = −4. The central-difference gradient's maximum absolute discrepancy is approximately **3.20×10⁻¹¹**.

A simultaneous step with learning rate 0.01 subtracts 0.01 times each original gradient. New parameters are **[0.54, 0.52, 2.015, 0.01]**. The new hidden value is 1.6; prediction is **3.234**; loss is **0.293378**.

The separate learning-rate-0.1 experiment starts from the original parameters again, not from the rate-0.01 result. It produces **[0.9, 0.7, 2.15, 0.1]**, prediction **5.475** and loss approximately **1.0878125**. The negative gradient was correct locally, but that larger step overshot. A correct derivative does not guarantee every step size will reduce loss.

### Read the source without getting lost

Find `f`, then `derivative`, then `network`, then `run`. `THETA` supplies the starting parameters. `run` connects the mathematical pieces and returns labelled results. The final entry-point block writes and prints them through a shared helper. Read the short mathematical functions before the output-formatting code. At a ReLU corner z = 0, the implementation uses a stated convention; a central difference there does not establish differentiability.

In a copied release, add another learning rate to the existing rate list, predict the effect and compare it. Keep all gradients from the same old parameter vector during one simultaneous update. Do not overwrite your untouched reference or rewrite expected values merely to hide a failure.

## Example 2: the same chain rule, now with a probability

**Volume 2, Chapter 15, V2C15-CASE01.** Open [the chapter page](chapters/volume-02/chapter-15/README_EN.md), [fixture](releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/fixture.json), [algorithm source](releases/volume-02-0.2.0/src/volume2_companion/chapter15.py) and [recorded rerun](reports/examples/V2C15-CASE01.json).

```sh
python run_chapter.py --volume 2 --chapter 15 --case 1
```

The inputs are x = [1,2], w = [0.2,−0.1], b = 0.3, v = 0.4, c = −0.2, target y = 1, learning rate 0.1. Parameter order is **w0, w1, b, v, c**. This is a classifier using a sigmoid and binary cross-entropy; its loss convention differs from Example 1's squared-error regression.

### Reconstruct the forward pass

- z = w·x + b = 0.2×1 − 0.1×2 + 0.3 = **0.3**.
- h = max(0,z) = **0.3**.
- a = vh + c = 0.4×0.3 − 0.2 = **−0.08**.
- p = 1/(1 + exp(−a)) = **0.4800106598444182**.
- With y = 1, loss = −ln(p) = **0.73394696731759** nats.

The stable source expression is softplus(a) − ya, which is the same binary-cross-entropy objective. The logit gradient is p − y = **−0.5199893401555817**. Apply the chain rule through v and the active ReLU to obtain:

**[−0.2079957360622327, −0.4159914721244654, −0.2079957360622327, −0.15599680204667452, −0.5199893401555817]**.

The central-difference check uses epsilon 0.000001 and has maximum error about **2.20×10⁻¹¹**. Subtract 0.1 times the old gradient from every parameter simultaneously. The new parameter vector is approximately **[0.2207995736, −0.0584008528, 0.3207995736, 0.4155996802, −0.1480010660]**.

The fresh output reports `updated_probability` **0.5071356692255375** and `updated_loss` **0.6789767190265269**. The target is 1, so raising p moves in the helpful direction for this observation. One step on one constructed input is not a trained commercial model or proof of generalization. CASE02 in this chapter is a separate optimizer-arithmetic lab; do not substitute its outputs for these.

### Understand the file roles

`fixture.json` is the input and assumption record. The chapter's `run.py` is a short entry point. The algorithm is in `src/volume2_companion/chapter15.py`. `expected.json` is the preserved reference output. The tests check mathematical properties and gradients independently. The English and Tamil readers use exactly these same files.

## Optional Example 3: why a future token cannot affect the first causal output

**Volume 2, Chapter 17, V2C17-CASE01.** [Chapter page](chapters/volume-02/chapter-17/README_EN.md); [recorded rerun](reports/examples/V2C17-CASE01.json).

```sh
python run_chapter.py --volume 2 --chapter 17
```

Q = K = [[1,0],[0,1]], and V = [[2,0],[0,4]]. Divide QKᵀ by √2. The score diagonal is approximately 0.7071067812; off-diagonal scores are zero. The causal mask lets the first query use only its own key, so the first weights are **[1,0]** and its output is **[2,0]**.

For the second query both keys are allowed. Softmax on [0,1/√2] gives weights approximately **[0.3302384507,0.6697615493]**. Their weighted sum of V is **[0.6604769013,2.6790461973]**. This matches the executed `causal_output`.

In a copied fixture, changing only the second value vector cannot change the first causal output. It can change the second. An attention weight is a calculation, not evidence that a statement is true or that an item satisfies a safety restriction.

## A reusable learning record

For any chapter, write five short notes: the question, the equation, the input and units, the expected intermediate result, and what the program actually returned. Then add one sentence explaining agreement or discrepancy. Record the case ID and source release. This turns running a command into understanding the mathematics.
