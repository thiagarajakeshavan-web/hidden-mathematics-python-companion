# Volume 2 · Chapter 19: Fine-tuning, preference optimization and LoRA

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

Separate a two-candidate SFT update, reference-corrected DPO and an additive rank-one LoRA calculation. Compare definitions, loss signs and derivatives. These tiny calculations do not fine-tune a production LLM, establish alignment or measure real human preferences.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 2 --chapter 19 --list
python run_chapter.py --volume 2 --chapter 19
```

## V2C19-CASE01

- Algorithm source: [releases/volume-02-0.2.0/src/volume2_companion/chapter19.py](../../../releases/volume-02-0.2.0/src/volume2_companion/chapter19.py)
- Executable entry point: [releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-19/case-01/run.py](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-19/case-01/run.py)
- Saved result or expected reference: [releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-19/case-01/expected.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-19/case-01/expected.json)
- Input/input definition: [releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-19/case-01/fixture.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-19/case-01/fixture.json)
- Detailed original guide: [README.md](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-19/case-01/README.md)

```sh
python run_chapter.py --volume 2 --chapter 19 --case 1
```

## Interpret, check, then experiment

The entry point computes a fresh result and checks it against `expected.json`. A mismatch is a useful reference-check failure. To explore a changed fixture, copy the whole release and use its `run_cases.py` without `--verify`. The complete Volume 2 suite has 287 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

