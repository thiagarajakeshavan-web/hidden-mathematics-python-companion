# தொகுதி 2 · அத்தியாயம் 15: நரம்பியல் வலைப்பின்னல்கள் [Neural Networks] மற்றும் பின்பரவல் [Backpropagation]

[தொடக்க வழிகாட்டி](../../../START_HERE_TA.md) · [அத்தியாய அட்டவணை [Chapter Index]](../../../CHAPTER_INDEX_TA.md)

இந்தத் தலைப்பு நிரலைக் கண்டுபிடிக்க உதவும் வழிகாட்டிப் பெயர் [Navigation Label]. நூலின் அத்தியாயம்/எடுத்துக்காட்டு அடையாளமே [Case ID] பொருத்தத்தை நிர்ணயிக்கிறது. ஒரே நிரல் [Code] இரு மொழிப் பதிப்புகளுக்கும் [Language Editions] பயன்படுகிறது.

CASE01 இரண்டு பண்புகளுடைய [Features] திருத்தப்பட்ட நேரியல் அலகு [ReLU]/சிக்மாய்டு [Sigmoid] முன்பரவலை [Forward Pass], பகுப்பாய்வு மற்றும் எண் சரிவுகளுடன் [Analytical and Numerical Gradients] இணைத்து ஒரே நேர SGD படியை [Simultaneous SGD Step] எடுக்கிறது. இழப்பு [Loss] சுமார் 0.733947-இலிருந்து 0.678977 ஆகிறது. CASE02 கொடுத்த இரண்டு ஒற்றைமதிப்புச் சரிவுகளை [Scalar Gradients] AdaGrad, RMSProp, சாய்வுத் திருத்த Adam [Bias-corrected Adam] ஆகியவற்றில் பயன்படுத்துகிறது. இவை முழு மாதிரிப் பயிற்சி அளவுகோல் [Model-training Benchmark] அல்ல.

## இயக்கும் முன் [Before Running]

முதலில் தொடக்க வழிகாட்டியைப் பின்பற்றுங்கள். கீழே `python` என்பது உங்கள் தனிச் சூழலின் இயக்கி [Environment Interpreter]. கட்டளையை [Command] ஒருங்கிணைந்த முதன்மை அடைவிலிருந்து [Combined Root] இயக்குங்கள்; இந்த அத்தியாய அடைவிலிருந்து [Chapter Folder] அல்ல. `--list` பாதைகளை [Paths] மட்டும் காட்டும்.

```sh
python run_chapter.py --volume 2 --chapter 15 --list
python run_chapter.py --volume 2 --chapter 15
```

[முழுச் செய்முறை விளக்கம் [Worked Walkthrough]](../../../WORKED_EXAMPLES_TA.md)

## V2C15-CASE01

- மூலநிரல் [Source Code]: [releases/volume-02-0.2.0/src/volume2_companion/chapter15.py](../../../releases/volume-02-0.2.0/src/volume2_companion/chapter15.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/run.py](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/run.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/expected.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/expected.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/fixture.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/fixture.json)
- விரிவான முதன்மை வழிகாட்டி [Detailed Original Guide]: [README_TA.md](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/README_TA.md)

```sh
python run_chapter.py --volume 2 --chapter 15 --case 1
```

## V2C15-CASE02

- மூலநிரல் [Source Code]: [releases/volume-02-0.2.0/src/volume2_companion/chapter15_optimizers.py](../../../releases/volume-02-0.2.0/src/volume2_companion/chapter15_optimizers.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/run.py](../../../releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/run.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/expected.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/expected.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/fixture.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/fixture.json)
- விரிவான முதன்மை வழிகாட்டி [Detailed Original Guide]: [README_TA.md](../../../releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/README_TA.md)

```sh
python run_chapter.py --volume 2 --chapter 15 --case 2
```

## முடிவை விளக்குவது [Interpreting the Result]

நுழைவுநிரல் [Entry Point] புதிய முடிவைக் [Result] கணக்கிட்டு `expected.json`-உடன் ஒப்பிடுகிறது. பொருந்தாவிட்டால் பிழை [Error] தருவது பாதுகாப்பான குறிப்பு [Reference] சோதனை. மாற்றிய மாதிரி உள்ளீட்டை [Fixture] ஆராய்வதற்கு முழு வெளியீட்டை [Release] நகலெடுத்து, அதன் `run_cases.py`-ஐ `--verify` இன்றி இயக்கலாம். முழுத் தொகுதி 2 சோதனைத் தொகுப்பில் [Test Suite] 287 சோதனைகள் [Tests] உள்ளன.

ஒரு சமன்பாட்டை [Equation] தேர்ந்தெடுத்து, உள்ளீடும் [Input] அளவலகும் [Unit] குறித்துக் கொண்டு, ஓர் இடைநிலை மதிப்பைக் [Intermediate Value] கையால் கணக்கிடுங்கள். பிறகு முடிவுடன் [Result] ஒப்பிடுங்கள். மாற்றமற்ற நகலைப் பாதுகாத்து, தனிப் பரிசோதனை நகலில் [Experiment Copy] ஒன்றை மட்டும் மாற்றுங்கள். பிழையை மறைக்க எதிர்பார்ப்பு முடிவை [Expected Result] மாற்ற வேண்டாம். செயற்கைத் தரவு [Synthetic Data] உண்மையான வணிகச் செயல்திறனையோ [Business Performance] பாதுகாப்பையோ நிறுவாது.

