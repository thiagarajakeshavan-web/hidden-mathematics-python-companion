# Volume 2 · Chapter 15: Neural networks and backpropagation

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

CASE01 connects a two-feature ReLU/sigmoid forward pass to analytical and numerical gradients, then one simultaneous SGD step. Loss changes from about 0.733947 to 0.678977 for this fixture. CASE02 separately applies two supplied scalar gradients to AdaGrad, RMSProp and bias-corrected Adam. Neither case is a full model-training benchmark.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 2 --chapter 15 --list
python run_chapter.py --volume 2 --chapter 15
```

[Read the detailed worked example](../../../WORKED_EXAMPLES_EN.md)

## V2C15-CASE01

- Algorithm source: [releases/volume-02-0.2.0/src/volume2_companion/chapter15.py](../../../releases/volume-02-0.2.0/src/volume2_companion/chapter15.py)
- Executable entry point: [releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/run.py](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/run.py)
- Saved result or expected reference: [releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/expected.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/expected.json)
- Input/input definition: [releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/fixture.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/fixture.json)
- Detailed original guide: [README.md](../../../releases/volume-02-0.2.0/volume-02/edition-0.1.0/chapter-15/case-01/README.md)

```sh
python run_chapter.py --volume 2 --chapter 15 --case 1
```

## V2C15-CASE02

- Algorithm source: [releases/volume-02-0.2.0/src/volume2_companion/chapter15_optimizers.py](../../../releases/volume-02-0.2.0/src/volume2_companion/chapter15_optimizers.py)
- Executable entry point: [releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/run.py](../../../releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/run.py)
- Saved result or expected reference: [releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/expected.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/expected.json)
- Input/input definition: [releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/fixture.json](../../../releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/fixture.json)
- Detailed original guide: [README.md](../../../releases/volume-02-0.2.0/volume-02/edition-0.2.0/chapter-15/case-02/README.md)

```sh
python run_chapter.py --volume 2 --chapter 15 --case 2
```

## Interpret, check, then experiment

The entry point computes a fresh result and checks it against `expected.json`. A mismatch is a useful reference-check failure. To explore a changed fixture, copy the whole release and use its `run_cases.py` without `--verify`. The complete Volume 2 suite has 287 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

