# Volume 1 · Chapter 14: Looking Ahead to Volume 2

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This is the brief preview of Volume 2. There is intentionally no required code lab, fixture or expected output. Read the book’s overview of neural networks, LLMs and production AI. The next full technical lab is Volume 2, Chapter 15.

[Continue to Chapter 15](../../volume-02/chapter-15/README_EN.md)
