# Volume 1 · Chapter 11: Naive Bayes, kNN and SVM

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

Connect Bayes smoothing, distance scaling and the margin to the source. The small Bernoulli example gives posterior 8/9; alpha=1 smoothing gives 16/19. The larger Gaussian NB/kNN/SVM comparison uses separate base-training, calibration and test rows. A raw sigmoid of an SVM margin is not a fitted calibrator.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 11 --list
python run_chapter.py --volume 1 --chapter 11
```

## V1C11-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C11/lab.py](../../../releases/volume-01-1.2.0/V1C11/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C11/lab.py](../../../releases/volume-01-1.2.0/V1C11/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C11/results.json](../../../releases/volume-01-1.2.0/V1C11/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C11/lab.py](../../../releases/volume-01-1.2.0/V1C11/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C11/bayes_counts.csv](../../../releases/volume-01-1.2.0/V1C11/bayes_counts.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C11/knn_input.csv](../../../releases/volume-01-1.2.0/V1C11/knn_input.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C11/svm_input.csv](../../../releases/volume-01-1.2.0/V1C11/svm_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C11/README.md)

```sh
python run_chapter.py --volume 1 --chapter 11 --case 1
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

