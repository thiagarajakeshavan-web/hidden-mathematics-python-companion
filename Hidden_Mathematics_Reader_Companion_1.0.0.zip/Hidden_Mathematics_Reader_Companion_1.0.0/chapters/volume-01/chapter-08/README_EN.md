# Volume 1 · Chapter 8: Model Evaluation

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

At threshold 0.5, count TP=2, FP=1, FN=1, TN=4 before reading metrics. AUC is 0.8. The included leakage examples are intentionally invalid workflows. Do not choose a production threshold from the final-test cost table or treat eight observations as proof of calibration.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 8 --list
python run_chapter.py --volume 1 --chapter 8
```

## V1C08-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C08/lab.py](../../../releases/volume-01-1.2.0/V1C08/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C08/lab.py](../../../releases/volume-01-1.2.0/V1C08/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C08/results.json](../../../releases/volume-01-1.2.0/V1C08/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C08/lab.py](../../../releases/volume-01-1.2.0/V1C08/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C08/classification_input.csv](../../../releases/volume-01-1.2.0/V1C08/classification_input.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C08/regression_input.csv](../../../releases/volume-01-1.2.0/V1C08/regression_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C08/README.md)

```sh
python run_chapter.py --volume 1 --chapter 8 --case 1
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

