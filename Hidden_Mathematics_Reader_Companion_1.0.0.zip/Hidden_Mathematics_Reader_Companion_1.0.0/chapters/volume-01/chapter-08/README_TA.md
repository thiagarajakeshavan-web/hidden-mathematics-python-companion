# தொகுதி 1 · அத்தியாயம் 8: மாதிரி மதிப்பீடு [Model Evaluation]

[தொடக்க வழிகாட்டி](../../../START_HERE_TA.md) · [அத்தியாய அட்டவணை [Chapter Index]](../../../CHAPTER_INDEX_TA.md)

இந்தத் தலைப்பு நிரலைக் கண்டுபிடிக்க உதவும் வழிகாட்டிப் பெயர் [Navigation Label]. நூலின் அத்தியாயம்/எடுத்துக்காட்டு அடையாளமே [Case ID] பொருத்தத்தை நிர்ணயிக்கிறது. ஒரே நிரல் [Code] இரு மொழிப் பதிப்புகளுக்கும் [Language Editions] பயன்படுகிறது.

0.5 முடிவு வரம்பில் [Threshold] TP=2, FP=1, FN=1, TN=4 என்று எண்ணிய பிறகு மதிப்பீடுகளை [Metrics] படியுங்கள். வளைவுக்குக் கீழான பரப்பு [AUC] 0.8. தரவுக் கசிவு [Data Leakage] எடுத்துக்காட்டுகள் வேண்டுமென்றே தவறான பணிப்பாய்வுகள் [Invalid Workflows]. இறுதிச் சோதனைச் செலவு அட்டவணையிலிருந்து [Final-test Cost Table] செயல்பாட்டு முடிவு வரம்பை [Production Threshold] தேர்ந்தெடுக்காதீர்கள்; எட்டு கண்காணிப்புகள் [Observations] நிகழ்தகவு ஒத்திசைவிற்குச் [Calibration] சான்றல்ல.

## இயக்கும் முன் [Before Running]

முதலில் தொடக்க வழிகாட்டியைப் பின்பற்றுங்கள். கீழே `python` என்பது உங்கள் தனிச் சூழலின் இயக்கி [Environment Interpreter]. கட்டளையை [Command] ஒருங்கிணைந்த முதன்மை அடைவிலிருந்து [Combined Root] இயக்குங்கள்; இந்த அத்தியாய அடைவிலிருந்து [Chapter Folder] அல்ல. `--list` பாதைகளை [Paths] மட்டும் காட்டும்.

```sh
python run_chapter.py --volume 1 --chapter 8 --list
python run_chapter.py --volume 1 --chapter 8
```

## V1C08-CASE01

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/V1C08/lab.py](../../../releases/volume-01-1.2.0/V1C08/lab.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/V1C08/lab.py](../../../releases/volume-01-1.2.0/V1C08/lab.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/V1C08/results.json](../../../releases/volume-01-1.2.0/V1C08/results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C08/lab.py](../../../releases/volume-01-1.2.0/V1C08/lab.py)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C08/classification_input.csv](../../../releases/volume-01-1.2.0/V1C08/classification_input.csv)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C08/regression_input.csv](../../../releases/volume-01-1.2.0/V1C08/regression_input.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/V1C08/README.md)

```sh
python run_chapter.py --volume 1 --chapter 8 --case 1
```

## முடிவை விளக்குவது [Interpreting the Result]

இந்தத் தொகுதியின் நிரல்கள் [Programs] வெளியீட்டு அடைவிற்குள் [Release Folder] முடிவுக் கோப்புகளை [Result Files] எழுதும். சில CSV கோப்புகள் நிரல் மாறிலிகளை [Code Constants] வாசிப்பதற்காக மீண்டும் காட்டுகின்றன; உண்மையில் எதிலிருந்து உள்ளீடு [Input] வாசிக்கப்படுகிறது என்பதைப் பாருங்கள். முழுச் சோதனைத் தொகுப்பில் [Test Suite] 178 சோதனைகள் [Tests] உள்ளன.

ஒரு சமன்பாட்டை [Equation] தேர்ந்தெடுத்து, உள்ளீடும் [Input] அளவலகும் [Unit] குறித்துக் கொண்டு, ஓர் இடைநிலை மதிப்பைக் [Intermediate Value] கையால் கணக்கிடுங்கள். பிறகு முடிவுடன் [Result] ஒப்பிடுங்கள். மாற்றமற்ற நகலைப் பாதுகாத்து, தனிப் பரிசோதனை நகலில் [Experiment Copy] ஒன்றை மட்டும் மாற்றுங்கள். பிழையை மறைக்க எதிர்பார்ப்பு முடிவை [Expected Result] மாற்ற வேண்டாம். செயற்கைத் தரவு [Synthetic Data] உண்மையான வணிகச் செயல்திறனையோ [Business Performance] பாதுகாப்பையோ நிறுவாது.

