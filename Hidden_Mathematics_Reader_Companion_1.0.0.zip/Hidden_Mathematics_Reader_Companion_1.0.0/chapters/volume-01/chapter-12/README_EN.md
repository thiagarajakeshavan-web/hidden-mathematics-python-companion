# Volume 1 · Chapter 12: Decision Trees, Random Forests and Gradient Boosting

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

The same source runs three cases. CASE01 checks split gains; CASE02 lowers regression MSE from 10 to 3.25 with the stated half-sized residual step; CASE03 selects the logistic baseline by validation log loss before testing. A tree or ensemble does not automatically beat a simpler model. Read boosting_fixture and ensemble_comparison in the shared result.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 12 --list
python run_chapter.py --volume 1 --chapter 12
```

## V1C12-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C12/results.json](../../../releases/volume-01-1.2.0/V1C12/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C12/boosting_input.csv](../../../releases/volume-01-1.2.0/V1C12/boosting_input.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C12/tree_input.csv](../../../releases/volume-01-1.2.0/V1C12/tree_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C12/README.md)

```sh
python run_chapter.py --volume 1 --chapter 12 --case 1
```

This original entry point runs the chapter’s bundled cases together, even when one case is selected. The launcher runs the shared source only once.

## V1C12-CASE02

- Algorithm source: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C12/results.json](../../../releases/volume-01-1.2.0/V1C12/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C12/boosting_input.csv](../../../releases/volume-01-1.2.0/V1C12/boosting_input.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C12/tree_input.csv](../../../releases/volume-01-1.2.0/V1C12/tree_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C12/README.md)

```sh
python run_chapter.py --volume 1 --chapter 12 --case 2
```

Read the `boosting_fixture` section of the shared result file.

This original entry point runs the chapter’s bundled cases together, even when one case is selected. The launcher runs the shared source only once.

## V1C12-CASE03

- Algorithm source: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C12/results.json](../../../releases/volume-01-1.2.0/V1C12/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C12/boosting_input.csv](../../../releases/volume-01-1.2.0/V1C12/boosting_input.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C12/tree_input.csv](../../../releases/volume-01-1.2.0/V1C12/tree_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C12/README.md)

```sh
python run_chapter.py --volume 1 --chapter 12 --case 3
```

Read the `ensemble_comparison` section of the shared result file.

This original entry point runs the chapter’s bundled cases together, even when one case is selected. The launcher runs the shared source only once.

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

