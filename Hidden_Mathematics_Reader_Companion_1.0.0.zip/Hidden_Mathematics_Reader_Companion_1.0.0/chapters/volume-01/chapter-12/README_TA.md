# தொகுதி 1 · அத்தியாயம் 12: முடிவு மரங்கள் [Decision Trees], சீரற்ற காடுகள் [Random Forests], சரிவு ஊக்குவிப்பு [Gradient Boosting]

[தொடக்க வழிகாட்டி](../../../START_HERE_TA.md) · [அத்தியாய அட்டவணை [Chapter Index]](../../../CHAPTER_INDEX_TA.md)

இந்தத் தலைப்பு நிரலைக் கண்டுபிடிக்க உதவும் வழிகாட்டிப் பெயர் [Navigation Label]. நூலின் அத்தியாயம்/எடுத்துக்காட்டு அடையாளமே [Case ID] பொருத்தத்தை நிர்ணயிக்கிறது. ஒரே நிரல் [Code] இரு மொழிப் பதிப்புகளுக்கும் [Language Editions] பயன்படுகிறது.

ஒரே மூலநிரல் [Source Code] மூன்று எடுத்துக்காட்டுகளை இயக்குகிறது. CASE01 பிரிப்பு மேம்பாட்டை [Split Gain] சோதிக்கிறது. CASE02 கொடுத்த அரை அளவு மீதப் பிழைப் படியால் [Residual Step] பின்னடைவு சராசரி வர்க்கப் பிழையை [Regression MSE] 10-இலிருந்து 3.25 ஆகக் குறைக்கிறது. CASE03 சோதனைக்கு [Test] முன் சரிபார்ப்பு மடக்கை இழப்பால் [Validation Log Loss] லாஜிஸ்டிக் அடிப்படை மாதிரியை [Logistic Baseline] தேர்ந்தெடுக்கிறது. மரமோ [Tree] கூட்டமாதிரியோ [Ensemble] எளிய மாதிரியை [Model] எப்போதும் வெல்லாது. பகிரப்பட்ட முடிவில் [Shared Result] boosting_fixture, ensemble_comparison ஆகிய பகுதிகளைப் படியுங்கள்.

## இயக்கும் முன் [Before Running]

முதலில் தொடக்க வழிகாட்டியைப் பின்பற்றுங்கள். கீழே `python` என்பது உங்கள் தனிச் சூழலின் இயக்கி [Environment Interpreter]. கட்டளையை [Command] ஒருங்கிணைந்த முதன்மை அடைவிலிருந்து [Combined Root] இயக்குங்கள்; இந்த அத்தியாய அடைவிலிருந்து [Chapter Folder] அல்ல. `--list` பாதைகளை [Paths] மட்டும் காட்டும்.

```sh
python run_chapter.py --volume 1 --chapter 12 --list
python run_chapter.py --volume 1 --chapter 12
```

## V1C12-CASE01

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/V1C12/results.json](../../../releases/volume-01-1.2.0/V1C12/results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C12/boosting_input.csv](../../../releases/volume-01-1.2.0/V1C12/boosting_input.csv)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C12/tree_input.csv](../../../releases/volume-01-1.2.0/V1C12/tree_input.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/V1C12/README.md)

```sh
python run_chapter.py --volume 1 --chapter 12 --case 1
```

இந்த நுழைவுநிரல் [Entry Point] அத்தியாயத்தின் தொடர்புடைய எடுத்துக்காட்டுகளை ஒன்றாக இயக்கும். ஓர் எடுத்துக்காட்டைத் தேர்ந்தெடுப்பது மற்ற பகுதிகளை நீக்காது.

## V1C12-CASE02

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/V1C12/results.json](../../../releases/volume-01-1.2.0/V1C12/results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C12/boosting_input.csv](../../../releases/volume-01-1.2.0/V1C12/boosting_input.csv)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C12/tree_input.csv](../../../releases/volume-01-1.2.0/V1C12/tree_input.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/V1C12/README.md)

```sh
python run_chapter.py --volume 1 --chapter 12 --case 2
```

பகிரப்பட்ட முடிவில் [Shared Result] `boosting_fixture` பகுதியைப் படியுங்கள்.

இந்த நுழைவுநிரல் [Entry Point] அத்தியாயத்தின் தொடர்புடைய எடுத்துக்காட்டுகளை ஒன்றாக இயக்கும். ஓர் எடுத்துக்காட்டைத் தேர்ந்தெடுப்பது மற்ற பகுதிகளை நீக்காது.

## V1C12-CASE03

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/V1C12/results.json](../../../releases/volume-01-1.2.0/V1C12/results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C12/lab.py](../../../releases/volume-01-1.2.0/V1C12/lab.py)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C12/boosting_input.csv](../../../releases/volume-01-1.2.0/V1C12/boosting_input.csv)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C12/tree_input.csv](../../../releases/volume-01-1.2.0/V1C12/tree_input.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/V1C12/README.md)

```sh
python run_chapter.py --volume 1 --chapter 12 --case 3
```

பகிரப்பட்ட முடிவில் [Shared Result] `ensemble_comparison` பகுதியைப் படியுங்கள்.

இந்த நுழைவுநிரல் [Entry Point] அத்தியாயத்தின் தொடர்புடைய எடுத்துக்காட்டுகளை ஒன்றாக இயக்கும். ஓர் எடுத்துக்காட்டைத் தேர்ந்தெடுப்பது மற்ற பகுதிகளை நீக்காது.

## முடிவை விளக்குவது [Interpreting the Result]

இந்தத் தொகுதியின் நிரல்கள் [Programs] வெளியீட்டு அடைவிற்குள் [Release Folder] முடிவுக் கோப்புகளை [Result Files] எழுதும். சில CSV கோப்புகள் நிரல் மாறிலிகளை [Code Constants] வாசிப்பதற்காக மீண்டும் காட்டுகின்றன; உண்மையில் எதிலிருந்து உள்ளீடு [Input] வாசிக்கப்படுகிறது என்பதைப் பாருங்கள். முழுச் சோதனைத் தொகுப்பில் [Test Suite] 178 சோதனைகள் [Tests] உள்ளன.

ஒரு சமன்பாட்டை [Equation] தேர்ந்தெடுத்து, உள்ளீடும் [Input] அளவலகும் [Unit] குறித்துக் கொண்டு, ஓர் இடைநிலை மதிப்பைக் [Intermediate Value] கையால் கணக்கிடுங்கள். பிறகு முடிவுடன் [Result] ஒப்பிடுங்கள். மாற்றமற்ற நகலைப் பாதுகாத்து, தனிப் பரிசோதனை நகலில் [Experiment Copy] ஒன்றை மட்டும் மாற்றுங்கள். பிழையை மறைக்க எதிர்பார்ப்பு முடிவை [Expected Result] மாற்ற வேண்டாம். செயற்கைத் தரவு [Synthetic Data] உண்மையான வணிகச் செயல்திறனையோ [Business Performance] பாதுகாப்பையோ நிறுவாது.

