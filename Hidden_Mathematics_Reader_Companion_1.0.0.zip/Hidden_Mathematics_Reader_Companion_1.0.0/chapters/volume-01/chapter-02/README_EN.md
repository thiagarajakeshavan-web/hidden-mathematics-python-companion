# Volume 1 · Chapter 2: Calculus

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

Check f(w)=(2w−3)² at w=1: value 1 and derivative −4. Follow the network gradient [−4,−2,−1.5,−1]. The simultaneous rate-0.01 update lowers loss from 0.5 to 0.293378; rate 0.1 increases it to about 1.0878125. Each experiment starts from the original parameters. See the full worked walkthrough.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 2 --list
python run_chapter.py --volume 1 --chapter 2
```

[Read the detailed worked example](../../../WORKED_EXAMPLES_EN.md)

## V1C02-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C02/lab.py](../../../releases/volume-01-1.2.0/V1C02/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C02/lab.py](../../../releases/volume-01-1.2.0/V1C02/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C02/results.json](../../../releases/volume-01-1.2.0/V1C02/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C02/lab.py](../../../releases/volume-01-1.2.0/V1C02/lab.py)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C02/README.md)

```sh
python run_chapter.py --volume 1 --chapter 2 --case 1
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

