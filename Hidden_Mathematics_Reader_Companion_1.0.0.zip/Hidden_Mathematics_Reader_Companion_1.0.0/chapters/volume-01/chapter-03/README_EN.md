# Volume 1 · Chapter 3: Probability Theory

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

Distinguish sensitivity from the probability of a defect after a positive flag. The constructed base-rate example gives posterior 2/13, not 0.9. Demand mean is 1.1 and variance is 0.49. Read exact arithmetic separately from the seeded simulation; neither is real logistics data.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 3 --list
python run_chapter.py --volume 1 --chapter 3
```

## V1C03-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C03/lab.py](../../../releases/volume-01-1.2.0/V1C03/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C03/lab.py](../../../releases/volume-01-1.2.0/V1C03/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C03/results.json](../../../releases/volume-01-1.2.0/V1C03/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C03/lab.py](../../../releases/volume-01-1.2.0/V1C03/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C03/demand_input.csv](../../../releases/volume-01-1.2.0/V1C03/demand_input.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C03/parcel_counts.csv](../../../releases/volume-01-1.2.0/V1C03/parcel_counts.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C03/README.md)

```sh
python run_chapter.py --volume 1 --chapter 3 --case 1
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

