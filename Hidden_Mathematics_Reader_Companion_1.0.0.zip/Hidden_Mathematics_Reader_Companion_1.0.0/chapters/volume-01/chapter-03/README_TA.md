# தொகுதி 1 · அத்தியாயம் 3: நிகழ்தகவுக் கோட்பாடு [Probability Theory]

[தொடக்க வழிகாட்டி](../../../START_HERE_TA.md) · [அத்தியாய அட்டவணை [Chapter Index]](../../../CHAPTER_INDEX_TA.md)

இந்தத் தலைப்பு நிரலைக் கண்டுபிடிக்க உதவும் வழிகாட்டிப் பெயர் [Navigation Label]. நூலின் அத்தியாயம்/எடுத்துக்காட்டு அடையாளமே [Case ID] பொருத்தத்தை நிர்ணயிக்கிறது. ஒரே நிரல் [Code] இரு மொழிப் பதிப்புகளுக்கும் [Language Editions] பயன்படுகிறது.

உணர்திறனையும் [Sensitivity], நேர்மக் குறியீட்டிற்குப் பிந்தைய குறைபாட்டு நிகழ்தகவையும் [Posterior Probability] வேறுபடுத்துங்கள். செயற்கை அடிப்படை வீத [Base-rate] எடுத்துக்காட்டில் பின்னிகழ்தகவு [Posterior] 2/13; 0.9 அல்ல. தேவைச் சராசரி [Demand Mean] 1.1; மாறுபாட்டளவு [Variance] 0.49. துல்லியக் கணக்கையும் [Exact Arithmetic], விதையிடப்பட்ட உருவகப்படுத்தலையும் [Seeded Simulation] தனித்தனியாகப் படியுங்கள். இவை உண்மையான சரக்குப் போக்குவரத்துத் தரவுகள் [Logistics Data] அல்ல.

## இயக்கும் முன் [Before Running]

முதலில் தொடக்க வழிகாட்டியைப் பின்பற்றுங்கள். கீழே `python` என்பது உங்கள் தனிச் சூழலின் இயக்கி [Environment Interpreter]. கட்டளையை [Command] ஒருங்கிணைந்த முதன்மை அடைவிலிருந்து [Combined Root] இயக்குங்கள்; இந்த அத்தியாய அடைவிலிருந்து [Chapter Folder] அல்ல. `--list` பாதைகளை [Paths] மட்டும் காட்டும்.

```sh
python run_chapter.py --volume 1 --chapter 3 --list
python run_chapter.py --volume 1 --chapter 3
```

## V1C03-CASE01

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/V1C03/lab.py](../../../releases/volume-01-1.2.0/V1C03/lab.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/V1C03/lab.py](../../../releases/volume-01-1.2.0/V1C03/lab.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/V1C03/results.json](../../../releases/volume-01-1.2.0/V1C03/results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C03/lab.py](../../../releases/volume-01-1.2.0/V1C03/lab.py)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C03/demand_input.csv](../../../releases/volume-01-1.2.0/V1C03/demand_input.csv)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C03/parcel_counts.csv](../../../releases/volume-01-1.2.0/V1C03/parcel_counts.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/V1C03/README.md)

```sh
python run_chapter.py --volume 1 --chapter 3 --case 1
```

## முடிவை விளக்குவது [Interpreting the Result]

இந்தத் தொகுதியின் நிரல்கள் [Programs] வெளியீட்டு அடைவிற்குள் [Release Folder] முடிவுக் கோப்புகளை [Result Files] எழுதும். சில CSV கோப்புகள் நிரல் மாறிலிகளை [Code Constants] வாசிப்பதற்காக மீண்டும் காட்டுகின்றன; உண்மையில் எதிலிருந்து உள்ளீடு [Input] வாசிக்கப்படுகிறது என்பதைப் பாருங்கள். முழுச் சோதனைத் தொகுப்பில் [Test Suite] 178 சோதனைகள் [Tests] உள்ளன.

ஒரு சமன்பாட்டை [Equation] தேர்ந்தெடுத்து, உள்ளீடும் [Input] அளவலகும் [Unit] குறித்துக் கொண்டு, ஓர் இடைநிலை மதிப்பைக் [Intermediate Value] கையால் கணக்கிடுங்கள். பிறகு முடிவுடன் [Result] ஒப்பிடுங்கள். மாற்றமற்ற நகலைப் பாதுகாத்து, தனிப் பரிசோதனை நகலில் [Experiment Copy] ஒன்றை மட்டும் மாற்றுங்கள். பிழையை மறைக்க எதிர்பார்ப்பு முடிவை [Expected Result] மாற்ற வேண்டாம். செயற்கைத் தரவு [Synthetic Data] உண்மையான வணிகச் செயல்திறனையோ [Business Performance] பாதுகாப்பையோ நிறுவாது.

