# Volume 1 · Chapter 1: Linear Algebra

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

Start with signed cosine and a small linear system. Check cosines 0.96, −1 and 0, and solution [3,2]. Then read the SVD/PCA results: a sign reversal of an eigenvector does not change its subspace. These synthetic feature vectors do not prove product similarity in a live shop.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 1 --list
python run_chapter.py --volume 1 --chapter 1
```

## V1C01-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C01/lab.py](../../../releases/volume-01-1.2.0/V1C01/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C01/lab.py](../../../releases/volume-01-1.2.0/V1C01/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C01/results.json](../../../releases/volume-01-1.2.0/V1C01/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C01/lab.py](../../../releases/volume-01-1.2.0/V1C01/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C01/pca_input.csv](../../../releases/volume-01-1.2.0/V1C01/pca_input.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C01/vector_input.csv](../../../releases/volume-01-1.2.0/V1C01/vector_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C01/README.md)

```sh
python run_chapter.py --volume 1 --chapter 1 --case 1
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

