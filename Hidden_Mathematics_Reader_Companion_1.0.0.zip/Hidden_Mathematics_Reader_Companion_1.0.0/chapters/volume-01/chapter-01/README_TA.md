# தொகுதி 1 · அத்தியாயம் 1: நேரியல் இயற்கணிதம் [Linear Algebra]

[தொடக்க வழிகாட்டி](../../../START_HERE_TA.md) · [அத்தியாய அட்டவணை [Chapter Index]](../../../CHAPTER_INDEX_TA.md)

இந்தத் தலைப்பு நிரலைக் கண்டுபிடிக்க உதவும் வழிகாட்டிப் பெயர் [Navigation Label]. நூலின் அத்தியாயம்/எடுத்துக்காட்டு அடையாளமே [Case ID] பொருத்தத்தை நிர்ணயிக்கிறது. ஒரே நிரல் [Code] இரு மொழிப் பதிப்புகளுக்கும் [Language Editions] பயன்படுகிறது.

குறியுள்ள கோசைன் ஒற்றுமை [Signed Cosine Similarity], சிறிய நேரியல் அமைப்பு [Linear System] ஆகியவற்றில் தொடங்குங்கள். மதிப்புகள் 0.96, −1, 0; தீர்வு [3,2] என்பதைச் சரிபார்க்கவும். ஒரும மதிப்புப் பிரிப்பு [SVD], முதன்மைக் கூறுப் பகுப்பாய்வு [PCA] முடிவுகளைப் படிக்கும்போது தன்திசையனின் [Eigenvector] குறி மாறினாலும் அதன் துணைவெளி [Subspace] மாறாது என்பதை நினைவில் கொள்ளுங்கள். செயற்கைப் பண்புத் திசையன்கள் [Synthetic Feature Vectors] உண்மையான கடையில் பொருள் ஒற்றுமையை நிரூபிக்காது.

## இயக்கும் முன் [Before Running]

முதலில் தொடக்க வழிகாட்டியைப் பின்பற்றுங்கள். கீழே `python` என்பது உங்கள் தனிச் சூழலின் இயக்கி [Environment Interpreter]. கட்டளையை [Command] ஒருங்கிணைந்த முதன்மை அடைவிலிருந்து [Combined Root] இயக்குங்கள்; இந்த அத்தியாய அடைவிலிருந்து [Chapter Folder] அல்ல. `--list` பாதைகளை [Paths] மட்டும் காட்டும்.

```sh
python run_chapter.py --volume 1 --chapter 1 --list
python run_chapter.py --volume 1 --chapter 1
```

## V1C01-CASE01

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/V1C01/lab.py](../../../releases/volume-01-1.2.0/V1C01/lab.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/V1C01/lab.py](../../../releases/volume-01-1.2.0/V1C01/lab.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/V1C01/results.json](../../../releases/volume-01-1.2.0/V1C01/results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C01/lab.py](../../../releases/volume-01-1.2.0/V1C01/lab.py)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C01/pca_input.csv](../../../releases/volume-01-1.2.0/V1C01/pca_input.csv)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C01/vector_input.csv](../../../releases/volume-01-1.2.0/V1C01/vector_input.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/V1C01/README.md)

```sh
python run_chapter.py --volume 1 --chapter 1 --case 1
```

## முடிவை விளக்குவது [Interpreting the Result]

இந்தத் தொகுதியின் நிரல்கள் [Programs] வெளியீட்டு அடைவிற்குள் [Release Folder] முடிவுக் கோப்புகளை [Result Files] எழுதும். சில CSV கோப்புகள் நிரல் மாறிலிகளை [Code Constants] வாசிப்பதற்காக மீண்டும் காட்டுகின்றன; உண்மையில் எதிலிருந்து உள்ளீடு [Input] வாசிக்கப்படுகிறது என்பதைப் பாருங்கள். முழுச் சோதனைத் தொகுப்பில் [Test Suite] 178 சோதனைகள் [Tests] உள்ளன.

ஒரு சமன்பாட்டை [Equation] தேர்ந்தெடுத்து, உள்ளீடும் [Input] அளவலகும் [Unit] குறித்துக் கொண்டு, ஓர் இடைநிலை மதிப்பைக் [Intermediate Value] கையால் கணக்கிடுங்கள். பிறகு முடிவுடன் [Result] ஒப்பிடுங்கள். மாற்றமற்ற நகலைப் பாதுகாத்து, தனிப் பரிசோதனை நகலில் [Experiment Copy] ஒன்றை மட்டும் மாற்றுங்கள். பிழையை மறைக்க எதிர்பார்ப்பு முடிவை [Expected Result] மாற்ற வேண்டாம். செயற்கைத் தரவு [Synthetic Data] உண்மையான வணிகச் செயல்திறனையோ [Business Performance] பாதுகாப்பையோ நிறுவாது.

