# Volume 1 · Chapter 5: Optimization

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

CASE01 connects normalized squared loss, gradient descent and step size. At rate 0.2, weights begin [0,1,1.5,1.75,1.875]. CASE02 compares all 27 allocations of a three-line synthetic basket. CASE03 considers 30 lines and all seven nonempty store subsets: whole packs plus fees make ALDI-only A$109.20 the best stated fixture plan. CASE04 is one fictional vegan cooking kit for five, payable A$32.80; eligibility checks are not real allergen-safety verification. Do not confuse used ingredient cost with the whole checkout total.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 5 --list
python run_chapter.py --volume 1 --chapter 5
```

## V1C05-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C05/lab.py](../../../releases/volume-01-1.2.0/V1C05/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C05/lab.py](../../../releases/volume-01-1.2.0/V1C05/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C05/results.json](../../../releases/volume-01-1.2.0/V1C05/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C05/lab.py](../../../releases/volume-01-1.2.0/V1C05/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C05/regression_input.csv](../../../releases/volume-01-1.2.0/V1C05/regression_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C05/README.md)

```sh
python run_chapter.py --volume 1 --chapter 5 --case 1
```

## V1C05-CASE02

- Algorithm source: [releases/volume-01-1.2.0/shopsmart_examples/basket_comparison.py](../../../releases/volume-01-1.2.0/shopsmart_examples/basket_comparison.py)
- Executable entry point: [releases/volume-01-1.2.0/shopsmart_examples/basket_comparison.py](../../../releases/volume-01-1.2.0/shopsmart_examples/basket_comparison.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/shopsmart_examples/basket_results.json](../../../releases/volume-01-1.2.0/shopsmart_examples/basket_results.json)
- Input/input definition: [releases/volume-01-1.2.0/shopsmart_examples/basket_prices.csv](../../../releases/volume-01-1.2.0/shopsmart_examples/basket_prices.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/shopsmart_examples/README.md)

```sh
python run_chapter.py --volume 1 --chapter 5 --case 2
```

## V1C05-CASE03

- Algorithm source: [releases/volume-01-1.2.0/shopsmart_scenarios/grocery30.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/grocery30.py)
- Executable entry point: [releases/volume-01-1.2.0/shopsmart_scenarios/grocery30.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/grocery30.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/shopsmart_scenarios/grocery30_results.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/grocery30_results.json)
- Input/input definition: [releases/volume-01-1.2.0/shopsmart_scenarios/data/grocery30.csv](../../../releases/volume-01-1.2.0/shopsmart_scenarios/data/grocery30.csv)
- Detailed original guide: [README_EN.md](../../../releases/volume-01-1.2.0/shopsmart_scenarios/README_EN.md)

```sh
python run_chapter.py --volume 1 --chapter 5 --case 3
```

## V1C05-CASE04

- Algorithm source: [releases/volume-01-1.2.0/shopsmart_scenarios/dinner5.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/dinner5.py)
- Executable entry point: [releases/volume-01-1.2.0/shopsmart_scenarios/dinner5.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/dinner5.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/shopsmart_scenarios/dinner5_results.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/dinner5_results.json)
- Input/input definition: [releases/volume-01-1.2.0/shopsmart_scenarios/data/dinner5.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/data/dinner5.json)
- Detailed original guide: [README_EN.md](../../../releases/volume-01-1.2.0/shopsmart_scenarios/README_EN.md)

```sh
python run_chapter.py --volume 1 --chapter 5 --case 4
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

