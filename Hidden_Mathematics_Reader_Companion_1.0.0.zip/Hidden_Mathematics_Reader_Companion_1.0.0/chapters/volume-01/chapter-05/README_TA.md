# தொகுதி 1 · அத்தியாயம் 5: உகப்பாக்கம் [Optimization]

[தொடக்க வழிகாட்டி](../../../START_HERE_TA.md) · [அத்தியாய அட்டவணை [Chapter Index]](../../../CHAPTER_INDEX_TA.md)

இந்தத் தலைப்பு நிரலைக் கண்டுபிடிக்க உதவும் வழிகாட்டிப் பெயர் [Navigation Label]. நூலின் அத்தியாயம்/எடுத்துக்காட்டு அடையாளமே [Case ID] பொருத்தத்தை நிர்ணயிக்கிறது. ஒரே நிரல் [Code] இரு மொழிப் பதிப்புகளுக்கும் [Language Editions] பயன்படுகிறது.

CASE01 இயல்பாக்கப்பட்ட வர்க்க இழப்பு [Normalized Squared Loss], சரிவு இறக்கம் [Gradient Descent], படி அளவு [Step Size] ஆகியவற்றை இணைக்கிறது. 0.2 வீதத்தில் [Rate] எடைகள் [Weights] [0,1,1.5,1.75,1.875] என்று தொடங்கும். CASE02 மூன்று பொருள் வரிகளின் செயற்கைக் கூடைக்கு [Synthetic Basket] 27 ஒதுக்கீடுகளை [Allocations] ஒப்பிடுகிறது. CASE03-இல் 30 வரிகளும் ஏழு கடைத் துணைக்குழுக்களும் [Store Subsets] உள்ளன; முழுப் பொதிகளும் [Whole Packs] கட்டணங்களும் சேரும்போது ALDI மட்டும் A$109.20 என்ற திட்டமே சிறந்தது. CASE04 ஐவருக்கான கற்பனைத் தாவர உணவுக் கொள்முதல் தொகுப்பு [Vegan Cooking Kit]; மொத்தம் A$32.80. தகுதிச் சோதனை [Eligibility Check] உண்மையான ஒவ்வாமைப் பாதுகாப்பு உறுதி அல்ல. பயன்படுத்திய மூலப்பொருள் செலவையும் [Ingredient-use Cost], முழுக் கொள்முதல் செலவையும் [Checkout Total] கலக்காதீர்கள்.

## இயக்கும் முன் [Before Running]

முதலில் தொடக்க வழிகாட்டியைப் பின்பற்றுங்கள். கீழே `python` என்பது உங்கள் தனிச் சூழலின் இயக்கி [Environment Interpreter]. கட்டளையை [Command] ஒருங்கிணைந்த முதன்மை அடைவிலிருந்து [Combined Root] இயக்குங்கள்; இந்த அத்தியாய அடைவிலிருந்து [Chapter Folder] அல்ல. `--list` பாதைகளை [Paths] மட்டும் காட்டும்.

```sh
python run_chapter.py --volume 1 --chapter 5 --list
python run_chapter.py --volume 1 --chapter 5
```

## V1C05-CASE01

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/V1C05/lab.py](../../../releases/volume-01-1.2.0/V1C05/lab.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/V1C05/lab.py](../../../releases/volume-01-1.2.0/V1C05/lab.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/V1C05/results.json](../../../releases/volume-01-1.2.0/V1C05/results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C05/lab.py](../../../releases/volume-01-1.2.0/V1C05/lab.py)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C05/regression_input.csv](../../../releases/volume-01-1.2.0/V1C05/regression_input.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/V1C05/README.md)

```sh
python run_chapter.py --volume 1 --chapter 5 --case 1
```

## V1C05-CASE02

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/shopsmart_examples/basket_comparison.py](../../../releases/volume-01-1.2.0/shopsmart_examples/basket_comparison.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/shopsmart_examples/basket_comparison.py](../../../releases/volume-01-1.2.0/shopsmart_examples/basket_comparison.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/shopsmart_examples/basket_results.json](../../../releases/volume-01-1.2.0/shopsmart_examples/basket_results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/shopsmart_examples/basket_prices.csv](../../../releases/volume-01-1.2.0/shopsmart_examples/basket_prices.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/shopsmart_examples/README.md)

```sh
python run_chapter.py --volume 1 --chapter 5 --case 2
```

## V1C05-CASE03

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/shopsmart_scenarios/grocery30.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/grocery30.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/shopsmart_scenarios/grocery30.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/grocery30.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/shopsmart_scenarios/grocery30_results.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/grocery30_results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/shopsmart_scenarios/data/grocery30.csv](../../../releases/volume-01-1.2.0/shopsmart_scenarios/data/grocery30.csv)
- விரிவான முதன்மை வழிகாட்டி [Detailed Original Guide]: [README_TA.md](../../../releases/volume-01-1.2.0/shopsmart_scenarios/README_TA.md)

```sh
python run_chapter.py --volume 1 --chapter 5 --case 3
```

## V1C05-CASE04

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/shopsmart_scenarios/dinner5.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/dinner5.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/shopsmart_scenarios/dinner5.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/dinner5.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/shopsmart_scenarios/dinner5_results.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/dinner5_results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/shopsmart_scenarios/data/dinner5.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/data/dinner5.json)
- விரிவான முதன்மை வழிகாட்டி [Detailed Original Guide]: [README_TA.md](../../../releases/volume-01-1.2.0/shopsmart_scenarios/README_TA.md)

```sh
python run_chapter.py --volume 1 --chapter 5 --case 4
```

## முடிவை விளக்குவது [Interpreting the Result]

இந்தத் தொகுதியின் நிரல்கள் [Programs] வெளியீட்டு அடைவிற்குள் [Release Folder] முடிவுக் கோப்புகளை [Result Files] எழுதும். சில CSV கோப்புகள் நிரல் மாறிலிகளை [Code Constants] வாசிப்பதற்காக மீண்டும் காட்டுகின்றன; உண்மையில் எதிலிருந்து உள்ளீடு [Input] வாசிக்கப்படுகிறது என்பதைப் பாருங்கள். முழுச் சோதனைத் தொகுப்பில் [Test Suite] 178 சோதனைகள் [Tests] உள்ளன.

ஒரு சமன்பாட்டை [Equation] தேர்ந்தெடுத்து, உள்ளீடும் [Input] அளவலகும் [Unit] குறித்துக் கொண்டு, ஓர் இடைநிலை மதிப்பைக் [Intermediate Value] கையால் கணக்கிடுங்கள். பிறகு முடிவுடன் [Result] ஒப்பிடுங்கள். மாற்றமற்ற நகலைப் பாதுகாத்து, தனிப் பரிசோதனை நகலில் [Experiment Copy] ஒன்றை மட்டும் மாற்றுங்கள். பிழையை மறைக்க எதிர்பார்ப்பு முடிவை [Expected Result] மாற்ற வேண்டாம். செயற்கைத் தரவு [Synthetic Data] உண்மையான வணிகச் செயல்திறனையோ [Business Performance] பாதுகாப்பையோ நிறுவாது.

