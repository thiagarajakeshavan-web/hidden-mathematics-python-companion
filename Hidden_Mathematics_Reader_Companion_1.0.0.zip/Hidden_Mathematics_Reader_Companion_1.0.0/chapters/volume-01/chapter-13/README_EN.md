# Volume 1 · Chapter 13: Clustering and Dimensionality Reduction

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

CASE01 covers k-means; CASE02 covers PCA in the same lab. The exact two-cluster within-cluster sum of squares is 32/3. The rank-one PCA example has eigenvalues 20/3 and 0. Separate held-out transforms are fitted on training rows only. A cluster ID is not an established customer segment or a causal explanation.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 13 --list
python run_chapter.py --volume 1 --chapter 13
```

## V1C13-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C13/lab.py](../../../releases/volume-01-1.2.0/V1C13/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C13/lab.py](../../../releases/volume-01-1.2.0/V1C13/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C13/results.json](../../../releases/volume-01-1.2.0/V1C13/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C13/lab.py](../../../releases/volume-01-1.2.0/V1C13/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C13/clustering_input.csv](../../../releases/volume-01-1.2.0/V1C13/clustering_input.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C13/pca_input.csv](../../../releases/volume-01-1.2.0/V1C13/pca_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C13/README.md)

```sh
python run_chapter.py --volume 1 --chapter 13 --case 1
```

This original entry point runs the chapter’s bundled cases together, even when one case is selected. The launcher runs the shared source only once.

## V1C13-CASE02

- Algorithm source: [releases/volume-01-1.2.0/V1C13/lab.py](../../../releases/volume-01-1.2.0/V1C13/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C13/lab.py](../../../releases/volume-01-1.2.0/V1C13/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C13/results.json](../../../releases/volume-01-1.2.0/V1C13/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C13/lab.py](../../../releases/volume-01-1.2.0/V1C13/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C13/clustering_input.csv](../../../releases/volume-01-1.2.0/V1C13/clustering_input.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C13/pca_input.csv](../../../releases/volume-01-1.2.0/V1C13/pca_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C13/README.md)

```sh
python run_chapter.py --volume 1 --chapter 13 --case 2
```

Read the `pca_fixture` section of the shared result file.

This original entry point runs the chapter’s bundled cases together, even when one case is selected. The launcher runs the shared source only once.

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

