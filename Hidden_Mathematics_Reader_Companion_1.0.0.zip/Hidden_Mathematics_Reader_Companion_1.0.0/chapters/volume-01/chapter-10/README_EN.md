# Volume 1 · Chapter 10: Linear and Logistic Regression

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

CASE01 includes OLS slope 0.8 and intercept 1.5 plus separate held-out experiments. Supplied logistic coefficients are not fitted estimates. CASE02 separates synthetic price regression from an assumed timing decision. CASE03 compares fictional day-0/day-2/day-3 scenarios: risk-neutral expected cost chooses day 3, while minimax chooses today. Future prices and savings are not verified forecasts.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 10 --list
python run_chapter.py --volume 1 --chapter 10
```

## V1C10-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C10/lab.py](../../../releases/volume-01-1.2.0/V1C10/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C10/lab.py](../../../releases/volume-01-1.2.0/V1C10/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C10/results.json](../../../releases/volume-01-1.2.0/V1C10/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C10/lab.py](../../../releases/volume-01-1.2.0/V1C10/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C10/logistic_supplied_parameters.csv](../../../releases/volume-01-1.2.0/V1C10/logistic_supplied_parameters.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C10/regression_test.csv](../../../releases/volume-01-1.2.0/V1C10/regression_test.csv)
- Input/input definition: [releases/volume-01-1.2.0/V1C10/regression_train.csv](../../../releases/volume-01-1.2.0/V1C10/regression_train.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C10/README.md)

```sh
python run_chapter.py --volume 1 --chapter 10 --case 1
```

## V1C10-CASE02

- Algorithm source: [releases/volume-01-1.2.0/shopsmart_examples/forecast_timing.py](../../../releases/volume-01-1.2.0/shopsmart_examples/forecast_timing.py)
- Executable entry point: [releases/volume-01-1.2.0/shopsmart_examples/forecast_timing.py](../../../releases/volume-01-1.2.0/shopsmart_examples/forecast_timing.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/shopsmart_examples/forecast_results.json](../../../releases/volume-01-1.2.0/shopsmart_examples/forecast_results.json)
- Input/input definition: [releases/volume-01-1.2.0/shopsmart_examples/price_history.csv](../../../releases/volume-01-1.2.0/shopsmart_examples/price_history.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/shopsmart_examples/README.md)

```sh
python run_chapter.py --volume 1 --chapter 10 --case 2
```

## V1C10-CASE03

- Algorithm source: [releases/volume-01-1.2.0/shopsmart_scenarios/timing30.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/timing30.py)
- Executable entry point: [releases/volume-01-1.2.0/shopsmart_scenarios/timing30.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/timing30.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/shopsmart_scenarios/timing30_results.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/timing30_results.json)
- Input/input definition: [releases/volume-01-1.2.0/shopsmart_scenarios/data/grocery30.csv](../../../releases/volume-01-1.2.0/shopsmart_scenarios/data/grocery30.csv)
- Input/input definition: [releases/volume-01-1.2.0/shopsmart_scenarios/data/timing_scenarios.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/data/timing_scenarios.json)
- Detailed original guide: [README_EN.md](../../../releases/volume-01-1.2.0/shopsmart_scenarios/README_EN.md)

```sh
python run_chapter.py --volume 1 --chapter 10 --case 3
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

