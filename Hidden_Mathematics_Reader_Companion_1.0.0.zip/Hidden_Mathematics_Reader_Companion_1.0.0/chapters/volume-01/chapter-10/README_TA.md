# தொகுதி 1 · அத்தியாயம் 10: நேரியல் மற்றும் லாஜிஸ்டிக் பின்னடைவு [Linear and Logistic Regression]

[தொடக்க வழிகாட்டி](../../../START_HERE_TA.md) · [அத்தியாய அட்டவணை [Chapter Index]](../../../CHAPTER_INDEX_TA.md)

இந்தத் தலைப்பு நிரலைக் கண்டுபிடிக்க உதவும் வழிகாட்டிப் பெயர் [Navigation Label]. நூலின் அத்தியாயம்/எடுத்துக்காட்டு அடையாளமே [Case ID] பொருத்தத்தை நிர்ணயிக்கிறது. ஒரே நிரல் [Code] இரு மொழிப் பதிப்புகளுக்கும் [Language Editions] பயன்படுகிறது.

CASE01-இல் சாதாரணக் குறைந்த வர்க்கப் பின்னடைவு [OLS] சரிவு [Slope] 0.8; இடைமறிப்பு [Intercept] 1.5; தனியாக ஒதுக்கிவைத்த தரவுப் பரிசோதனைகளும் [Held-out Experiments] உள்ளன. கொடுத்த லாஜிஸ்டிக் குணகங்கள் [Logistic Coefficients] பொருத்தப்பட்ட மதிப்பீடுகள் [Fitted Estimates] அல்ல. CASE02 செயற்கை விலைப் பின்னடைவையும் [Synthetic Price Regression], ஊகிக்கப்பட்ட வாங்கும் நேர முடிவையும் [Timing Decision] பிரிக்கிறது. CASE03 கற்பனை நாள்-0/2/3 காட்சிநிலைகளை [Scenarios] ஒப்பிடுகிறது: இடர்-நடுநிலை எதிர்பார்க்கப்பட்ட செலவு [Risk-neutral Expected Cost] நாள் 3-ஐத் தேர்ந்தெடுக்கிறது; மோசமான முடிவைக் குறைக்கும் விதி [Minimax] இன்றையே தேர்ந்தெடுக்கிறது. எதிர்கால விலைகளும் சேமிப்பும் உறுதிசெய்யப்பட்ட முன்கணிப்புகள் [Verified Forecasts] அல்ல.

## இயக்கும் முன் [Before Running]

முதலில் தொடக்க வழிகாட்டியைப் பின்பற்றுங்கள். கீழே `python` என்பது உங்கள் தனிச் சூழலின் இயக்கி [Environment Interpreter]. கட்டளையை [Command] ஒருங்கிணைந்த முதன்மை அடைவிலிருந்து [Combined Root] இயக்குங்கள்; இந்த அத்தியாய அடைவிலிருந்து [Chapter Folder] அல்ல. `--list` பாதைகளை [Paths] மட்டும் காட்டும்.

```sh
python run_chapter.py --volume 1 --chapter 10 --list
python run_chapter.py --volume 1 --chapter 10
```

## V1C10-CASE01

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/V1C10/lab.py](../../../releases/volume-01-1.2.0/V1C10/lab.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/V1C10/lab.py](../../../releases/volume-01-1.2.0/V1C10/lab.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/V1C10/results.json](../../../releases/volume-01-1.2.0/V1C10/results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C10/lab.py](../../../releases/volume-01-1.2.0/V1C10/lab.py)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C10/logistic_supplied_parameters.csv](../../../releases/volume-01-1.2.0/V1C10/logistic_supplied_parameters.csv)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C10/regression_test.csv](../../../releases/volume-01-1.2.0/V1C10/regression_test.csv)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/V1C10/regression_train.csv](../../../releases/volume-01-1.2.0/V1C10/regression_train.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/V1C10/README.md)

```sh
python run_chapter.py --volume 1 --chapter 10 --case 1
```

## V1C10-CASE02

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/shopsmart_examples/forecast_timing.py](../../../releases/volume-01-1.2.0/shopsmart_examples/forecast_timing.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/shopsmart_examples/forecast_timing.py](../../../releases/volume-01-1.2.0/shopsmart_examples/forecast_timing.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/shopsmart_examples/forecast_results.json](../../../releases/volume-01-1.2.0/shopsmart_examples/forecast_results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/shopsmart_examples/price_history.csv](../../../releases/volume-01-1.2.0/shopsmart_examples/price_history.csv)
- ஆங்கில முதன்மை வழிகாட்டி [Original English Guide]: [README.md](../../../releases/volume-01-1.2.0/shopsmart_examples/README.md)

```sh
python run_chapter.py --volume 1 --chapter 10 --case 2
```

## V1C10-CASE03

- மூலநிரல் [Source Code]: [releases/volume-01-1.2.0/shopsmart_scenarios/timing30.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/timing30.py)
- நுழைவுநிரல் [Entry Point]: [releases/volume-01-1.2.0/shopsmart_scenarios/timing30.py](../../../releases/volume-01-1.2.0/shopsmart_scenarios/timing30.py)
- சேமிக்கப்பட்ட முடிவு [Saved Result]: [releases/volume-01-1.2.0/shopsmart_scenarios/timing30_results.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/timing30_results.json)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/shopsmart_scenarios/data/grocery30.csv](../../../releases/volume-01-1.2.0/shopsmart_scenarios/data/grocery30.csv)
- உள்ளீடு/உள்ளீட்டு வரையறை [Input/Input Definition]: [releases/volume-01-1.2.0/shopsmart_scenarios/data/timing_scenarios.json](../../../releases/volume-01-1.2.0/shopsmart_scenarios/data/timing_scenarios.json)
- விரிவான முதன்மை வழிகாட்டி [Detailed Original Guide]: [README_TA.md](../../../releases/volume-01-1.2.0/shopsmart_scenarios/README_TA.md)

```sh
python run_chapter.py --volume 1 --chapter 10 --case 3
```

## முடிவை விளக்குவது [Interpreting the Result]

இந்தத் தொகுதியின் நிரல்கள் [Programs] வெளியீட்டு அடைவிற்குள் [Release Folder] முடிவுக் கோப்புகளை [Result Files] எழுதும். சில CSV கோப்புகள் நிரல் மாறிலிகளை [Code Constants] வாசிப்பதற்காக மீண்டும் காட்டுகின்றன; உண்மையில் எதிலிருந்து உள்ளீடு [Input] வாசிக்கப்படுகிறது என்பதைப் பாருங்கள். முழுச் சோதனைத் தொகுப்பில் [Test Suite] 178 சோதனைகள் [Tests] உள்ளன.

ஒரு சமன்பாட்டை [Equation] தேர்ந்தெடுத்து, உள்ளீடும் [Input] அளவலகும் [Unit] குறித்துக் கொண்டு, ஓர் இடைநிலை மதிப்பைக் [Intermediate Value] கையால் கணக்கிடுங்கள். பிறகு முடிவுடன் [Result] ஒப்பிடுங்கள். மாற்றமற்ற நகலைப் பாதுகாத்து, தனிப் பரிசோதனை நகலில் [Experiment Copy] ஒன்றை மட்டும் மாற்றுங்கள். பிழையை மறைக்க எதிர்பார்ப்பு முடிவை [Expected Result] மாற்ற வேண்டாம். செயற்கைத் தரவு [Synthetic Data] உண்மையான வணிகச் செயல்திறனையோ [Business Performance] பாதுகாப்பையோ நிறுவாது.

