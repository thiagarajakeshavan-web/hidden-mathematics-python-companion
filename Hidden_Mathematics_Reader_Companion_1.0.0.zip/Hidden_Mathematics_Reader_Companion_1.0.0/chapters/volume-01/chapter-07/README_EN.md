# Volume 1 · Chapter 7: Statistical Foundations

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

Read exact bias–variance arithmetic before the larger regularization experiment. Model selection uses validation, not final test scores. CASE02 is a finite No Free Lunch illustration over a stated set of labelings; it does not say every algorithm performs identically on a structured real-world problem.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 7 --list
python run_chapter.py --volume 1 --chapter 7
```

## V1C07-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C07/lab.py](../../../releases/volume-01-1.2.0/V1C07/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C07/lab.py](../../../releases/volume-01-1.2.0/V1C07/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C07/results.json](../../../releases/volume-01-1.2.0/V1C07/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C07/lab.py](../../../releases/volume-01-1.2.0/V1C07/lab.py)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C07/README.md)

```sh
python run_chapter.py --volume 1 --chapter 7 --case 1
```

## V1C07-CASE02

- Algorithm source: [releases/volume-01-1.2.0/V1C07/CASE02/no_free_lunch.py](../../../releases/volume-01-1.2.0/V1C07/CASE02/no_free_lunch.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C07/CASE02/no_free_lunch.py](../../../releases/volume-01-1.2.0/V1C07/CASE02/no_free_lunch.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C07/CASE02/results.json](../../../releases/volume-01-1.2.0/V1C07/CASE02/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C07/CASE02/no_free_lunch.py](../../../releases/volume-01-1.2.0/V1C07/CASE02/no_free_lunch.py)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C07/CASE02/README.md)

```sh
python run_chapter.py --volume 1 --chapter 7 --case 2
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

