# Volume 1 · Chapter 4: Descriptive and Inferential Statistics

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

The five values have mean 50. Distinguish sample variance from the maximum-likelihood variance convention. CASE02 separately compares MLE 7/10, MAP 2/3 under Beta(2,2), and posterior mean 9/14. A confidence interval is not a posterior probability for a fixed parameter; a chosen prior is not evidence of better prediction.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 4 --list
python run_chapter.py --volume 1 --chapter 4
```

## V1C04-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C04/lab.py](../../../releases/volume-01-1.2.0/V1C04/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C04/lab.py](../../../releases/volume-01-1.2.0/V1C04/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C04/results.json](../../../releases/volume-01-1.2.0/V1C04/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C04/lab.py](../../../releases/volume-01-1.2.0/V1C04/lab.py)
- Input/input definition: [releases/volume-01-1.2.0/V1C04/sample_input.csv](../../../releases/volume-01-1.2.0/V1C04/sample_input.csv)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C04/README.md)

```sh
python run_chapter.py --volume 1 --chapter 4 --case 1
```

## V1C04-CASE02

- Algorithm source: [releases/volume-01-1.2.0/V1C04/CASE02/map_mle.py](../../../releases/volume-01-1.2.0/V1C04/CASE02/map_mle.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C04/CASE02/map_mle.py](../../../releases/volume-01-1.2.0/V1C04/CASE02/map_mle.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C04/CASE02/results.json](../../../releases/volume-01-1.2.0/V1C04/CASE02/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C04/CASE02/map_mle.py](../../../releases/volume-01-1.2.0/V1C04/CASE02/map_mle.py)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C04/CASE02/README.md)

```sh
python run_chapter.py --volume 1 --chapter 4 --case 2
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

