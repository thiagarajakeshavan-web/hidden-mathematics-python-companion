# Volume 1 · Chapter 6: Information Theory

[Start here](../../../START_HERE_EN.md) · [Chapter index](../../../CHAPTER_INDEX_EN.md)

This topic label is a navigation aid. The book’s chapter and case identifiers establish the match. One implementation serves both language editions.

For the stated distributions, entropy is about 0.8112781245 bits and cross-entropy about 0.8832062193 bits; their difference is forward KL. Keep base-2 bits separate from natural-log nats. Stable softmax avoids numerical overflow without changing its mathematical probabilities.

## Before running

Complete the start-here setup first. Below, `python` means your environment’s interpreter. Run from the combined companion root, not this chapter folder. `--list` shows paths without executing.

```sh
python run_chapter.py --volume 1 --chapter 6 --list
python run_chapter.py --volume 1 --chapter 6
```

## V1C06-CASE01

- Algorithm source: [releases/volume-01-1.2.0/V1C06/lab.py](../../../releases/volume-01-1.2.0/V1C06/lab.py)
- Executable entry point: [releases/volume-01-1.2.0/V1C06/lab.py](../../../releases/volume-01-1.2.0/V1C06/lab.py)
- Saved result or expected reference: [releases/volume-01-1.2.0/V1C06/results.json](../../../releases/volume-01-1.2.0/V1C06/results.json)
- Input/input definition: [releases/volume-01-1.2.0/V1C06/lab.py](../../../releases/volume-01-1.2.0/V1C06/lab.py)
- Detailed original guide: [README.md](../../../releases/volume-01-1.2.0/V1C06/README.md)

```sh
python run_chapter.py --volume 1 --chapter 6 --case 1
```

## Interpret, check, then experiment

Volume 1 programs write result files inside the source-release folder. Some CSVs are readable mirrors of source constants: inspect what the program actually loads before editing them. The complete Volume 1 suite has 178 tests.

Choose one equation, note the input and units, calculate an intermediate value by hand, and compare it with the output. Keep an untouched reference and change only one thing in a separate full-release copy. Never change expected results just to hide an error. Synthetic results do not establish real business performance or safety.

