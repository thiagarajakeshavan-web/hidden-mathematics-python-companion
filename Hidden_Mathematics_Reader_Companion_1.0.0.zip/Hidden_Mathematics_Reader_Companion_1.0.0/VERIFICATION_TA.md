# சரிபார்ப்புப் பதிவு [Verification Record]: வாசகர் வழிகாட்டிப் பதிப்பு [Reader-guide Edition] 1.0.0

ஆசிரியர்: Keshavan Thiagaraja. சோதனைகள் [Checks] 6 அக்டோபர் 2026 அன்று இயக்கப்பட்டன.

## உண்மையில் பயன்படுத்திய சூழல் [Environment]

- CPython 3.12.14; Linux x86_64
- NumPy 2.3.5; SciPy 1.17.0; scikit-learn 1.8.0; joblib 1.5.3; threadpoolctl 3.6.0
- பாதுகாக்கப்பட்ட வெளியீடுகளுடன் [Releases] பொருந்தும், ஏற்கெனவே நிறுவிய பதிப்புநிர்ணய சார்புகள் [Pinned Dependencies]
- CPU இயக்கம் [Execution]; மாதிரிப் பதிவிறக்கம் [Model Download], கட்டண API [Paid API], சேவைக் கணக்கு [Service Account], அணுகல் சான்றுகள் [Credentials] இல்லை

புதிய திட்டத் தனிச் சூழல் [Virtual Environment] வெற்றிகரமாக உருவாக்கப்பட்டு அதன் Python/pip சரிபார்க்கப்பட்டன. அந்த வெற்றுச் சூழலில் [Empty Environment] சார்புத் தொகுப்புகள் [Dependencies] நிறுவப்படவில்லை. எண்ணியல் இயக்கங்கள் [Numerical Runs] ஏற்கெனவே நிறுவிய, பதிப்புகள் பொருந்தும் சூழலில் [Pinned Environment] நடந்தன. Windows, macOS, இணையம் வழியான புதிய சார்பு நிறுவல் [Fresh Dependency Installation], பொது GitHub பதிவிறக்கம்/நகலெடுப்பு அணுகல் [Public Download/Clone Access] ஆகியவை சோதிக்கப்படவில்லை.

## முடிந்த சோதனைகளும் இயக்கங்களும் [Tests and Runs]

| சரிபார்ப்பு [Check] | கண்ட முடிவு [Observed Result] |
|---|---|
| தொகுதி 1 முழு சோதனைத் தொகுப்பு [Full Test Suite]; எச்சரிக்கைகள் பிழைகளாக [Warnings as Errors] | 178 வெற்றி |
| தொகுதி 2 முழு சோதனைத் தொகுப்பு [Full Test Suite]; எச்சரிக்கைகள் பிழைகளாக [Warnings as Errors] | 287 வெற்றி |
| புதிய வாசகர் வழிசெலுத்தல் சோதனைத் தொகுப்பு [Reader-navigation Test Suite] | 18 வெற்றி |
| மூன்றின் மொத்தச் சோதனை முறைகள் [Test Methods] | 483 வெற்றி |
| தொகுதி 1 பழைய முழுப் பயிற்சி இயக்கி [All-lab Runner] | 13 அத்தியாயப் பயிற்சிகள் [Labs], இரண்டு முந்தைய ShopSmart சேர்க்கைகள் வெற்றி |
| தொகுதி 1 கூடுதல் எடுத்துக்காட்டு இயக்கி [Additional-case Runner] | பிந்தைய ஐந்து சேர்க்கைகள் வெற்றி |
| தொகுதி 2 பதிவு செய்யப்பட்ட முடிவு சரிபார்ப்புடன் [Recorded-result Verification] | 14 எடுத்துக்காட்டுகள் வெற்றி |
| புதிய உதவிநிரல் [Launcher] மூலம் முழு அத்தியாயங்கள் | 25 அத்தியாய இயக்கங்களும் [Chapter Launches] வெற்றி |
| வேறு நடப்பு அடைவிலிருந்து [Current Working Folder] இயக்கம் | V1C02, V2C15 CASE01 வெற்றி |
| முன்னோட்டம் 14, இல்லாத எடுத்துக்காட்டு, தவறான தொகுதி, பாதுகாப்பற்ற/இல்லாத பாதை [Path] | வழிசெலுத்தல் சோதனையில் [Navigation Suite] சரிபார்க்கப்பட்டது |

துல்லிய இணைப்பு அட்டவணையில் [Map] 26 அத்தியாயங்கள், 37 எடுத்துக்காட்டு அடையாளங்கள் [Case IDs], 34 தனித்தனி பழைய நுழைவுநிரல்கள் [Original Entry Points] உள்ளன. அத்தியாயம் 14 முன்னோட்டம். சில எடுத்துக்காட்டுகள் ஒரே நுழைவுநிரலைப் [Entry Point] பகிர்வதால் எடுத்துக்காட்டு எண்ணிக்கை [Case Count], நுழைவுநிரல் எண்ணிக்கை [Entry-point Count], சோதனை எண்ணிக்கை [Test Count] வெவ்வேறானவை.

முழு எண்ணியல் இயக்கச் சோதனை [Numerical Smoke Run] புதிய கோப்பு நகலில் [Fresh Filesystem Copy] நடந்தது; தொகுப்பிலுள்ள பாதுகாக்கப்பட்ட முடிவுகள் [Packaged Outputs] மாற்றப்படவில்லை. [validation.json](reports/validation.json) கட்டளைகள் [Commands], முடிவு நிலைகள் [Exit Statuses], வரம்பு [Scope] ஆகியவற்றைப் பதிவு செய்கிறது. இறுதியில் உள்ளீட்டுப் பாதைகளின் [Input Paths] மறுபதிவுகள் நீக்கப்பட்டன; வழிமுறையோ [Algorithm] இயக்க உதவிநிரலோ [Launcher] மாறவில்லை. அதன் பிறகும் 18 வழிசெலுத்தல் சோதனைகள் [Navigation Tests] வெற்றி பெற்றன.

## பழைய மூலநிரல் பாதுகாப்பு [Source Preservation]

பழைய சுருக்கக் கோப்பிலுள்ள [Archive] ஒவ்வொரு கோப்பும் பைட்டுக்கு பைட் [Byte-for-byte] ஒப்பிடப்பட்டது: **தொகுதி 1-இல் 120 கோப்புகள்**, **தொகுதி 2-இல் 113 கோப்புகள்**. வேறுபாடுகளோ அந்த வெளியீட்டு அடைவுகளுக்குள் [Release Trees] புதிய கோப்புகளோ இல்லை. இயக்கியின் இடைக்காலக் கோப்புகள் [Interpreter Cache Files] வழங்கப்படும் சுருக்கக் கோப்பில் [Distributed Archive] சேர்க்கப்படவில்லை.

பழைய ஒருமைப்பாட்டுச் சோதனைகளும் [Integrity Checks] வெற்றி: தொகுதி 1-இல் **119 பட்டியலிட்ட கோப்புகள் [Inventoried Files]**, தொகுதி 2-இல் **112 பட்டியலிட்ட கோப்புகள் [Inventoried Files]**. பட்டியல் கோப்பு [Manifest] தன்னையே சேர்க்காததால் மொத்தக் கோப்பு எண்ணிக்கையிலிருந்து ஒன்று குறைகிறது. தொகுதி 1-இன் தனி அடிப்படைப் பாதுகாப்புச் சோதனை [Baseline Preservation Check] **85 முந்தைய கோப்புகள்** மாற்றமின்றி இருப்பதை உறுதிசெய்தது. புதிய வழிசெலுத்தல் [Navigation], இருமொழி வழிகாட்டிகள், இயக்க உதவிநிரல் [Launcher], பதிவுகள் [Reports] ஆகியவை பழைய வெளியீட்டு அடைவுகளுக்கு [Release Folders] வெளியே உள்ளன.

இவை முந்தைய வெளியீட்டிலிருந்து [Release] தொடர்ச்சியை நிறுவுகின்றன. ஒருமைப்பாட்டு சுருக்கமதிப்பு [Integrity Hash] வெளியிட்டவரை அங்கீகரிப்பதோ [Authenticate Publisher], எல்லாக் கணிதக் கூற்றுகளையும் நிரூபிப்பதோ அல்ல. மூலநிரலையும் [Source Code] ஊகங்களையும் [Assumptions] படிப்பதற்கு மாற்றாகாது.

## சான்றுப் பதிவுகள் [Evidence Files]

- [தொகுதி 1 சோதனைகள் [Tests]](reports/v1_tests.log)
- [தொகுதி 2 சோதனைகள் [Tests]](reports/v2_tests.log)
- [இறுதி வழிசெலுத்தல் சோதனைகள் [Navigation Tests]](reports/reader_tests_final.log)
- [தொகுதி 1 ஒருமைப்பாடு [Integrity]](reports/v1_integrity.log), [தொகுதி 2 ஒருமைப்பாடு [Integrity]](reports/v2_integrity.log), [அடிப்படைப் பாதுகாப்பு [Baseline Preservation]](reports/v1_preservation.log)
- [தொகுதி 1 முழுப் பயிற்சி இயக்கம் [All-lab Run]](reports/v1_all.log), [சேர்க்கை இயக்கம் [Additions Run]](reports/v1_additions.log)
- புதிய செய்முறை முடிவுகள் [Worked Results]: [V1C02-CASE01](reports/examples/V1C02-CASE01.json), [V2C15-CASE01](reports/examples/V2C15-CASE01.json), [V2C17-CASE01](reports/examples/V2C17-CASE01.json)

புதிய அத்தியாயப் பக்கங்களும் அட்டவணைகளும் [Indices] உண்மையான உள்ளூர் கோப்புகளுடன் [Local Files] சரிபார்க்கப்பட்டன. இணைப்பு கோப்பைக் கண்டுபிடிப்பது எதிர்கால GitHub முகவரி [URL] செயல்படுகிறது என்று பொருளல்ல. [START_HERE_TA.md](START_HERE_TA.md) பொதுவான இடைமுக/நிறுவல் வழிமுறைகளுக்கு [Interface/Setup Instructions] அதிகாரப்பூர்வ GitHub/Python ஆவணங்களை [Documentation] காட்டுகிறது. இத்திட்டத்தின் பொது GitHub பணிப்பாய்வு [Public GitHub Flow] வெளியீடு நிலுவையில் இருப்பதால் சரிபார்க்கப்படவில்லை.

## மீதமுள்ள வரம்புகள் [Limitations]

இந்தச் சோதனைகள் [Tests] குறிப்பிட்ட செயற்கைக் கணக்கீடு [Synthetic Arithmetic], இடைமுகம் [Interface], ஏற்றுக்கொள்ளத்தக்க வேறுபாடு [Tolerance], தோல்விக் காட்சிகள் [Failure Cases] ஆகியவற்றைச் சரிபார்க்கின்றன. எங்கும் பொருந்தும் முழுச் சரித்தன்மை [Universal Correctness], செயல்பாட்டுத் தயார்நிலை [Production Readiness], பொதுமைப்படுத்தல் [Generalization], தனியுரிமை இணக்கம் [Privacy Compliance], பாதுகாப்பு, உண்மையான கடை ஆதரவு [Retailer Support], நடைமுறைச் சேமிப்பு ஆகியவற்றை நிரூபிக்கவில்லை. புதிய மறுபயன்பாட்டு உரிமம் [Reuse Licence], பொது களஞ்சிய முகவரி [Public Repository URL], வெளியீட்டுக் கூற்று [Publication Claim] சேர்க்கப்படவில்லை. பழைய பதிவுகள் [Logs] வரலாற்றுப் பதிவுகளாகவே உள்ளன; தற்போதைய ஒருங்கிணைந்த வழிகாட்டிக்கு [Combined Guide] இப்பதிவைப் பயன்படுத்துங்கள்.
